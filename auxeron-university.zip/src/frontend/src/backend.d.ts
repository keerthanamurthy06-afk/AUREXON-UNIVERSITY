import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Department {
    id: bigint;
    facultyCount: bigint;
    name: string;
    description: string;
    establishedYear: bigint;
    programs: Array<string>;
}
export interface Statistics {
    facultyCount: bigint;
    placementPercentage: number;
    totalStudents: bigint;
    yearsEstablished: bigint;
}
export interface Placement {
    id: bigint;
    package: number;
    year: bigint;
    company: string;
    studentsPlaced: bigint;
}
export interface Event {
    id: bigint;
    title: string;
    date: bigint;
    description: string;
    category: string;
    location: string;
}
export interface Program {
    id: bigint;
    duration: bigint;
    name: string;
    eligibility: string;
    seats: bigint;
    department: string;
}
export interface ResearchCenter {
    id: bigint;
    name: string;
    description: string;
    focusAreas: Array<string>;
    facultyMembers: Array<string>;
}
export interface News {
    id: bigint;
    title: string;
    content: string;
    date: bigint;
    excerpt: string;
    category: string;
}
export interface Faculty {
    id: bigint;
    name: string;
    designation: string;
    email: string;
    publications: bigint;
    specialization: string;
    department: string;
}
export interface backendInterface {
    getDepartment(id: bigint): Promise<Department>;
    getDepartments(): Promise<Array<Department>>;
    getEvents(): Promise<Array<Event>>;
    getFaculties(): Promise<Array<Faculty>>;
    getFaculty(id: bigint): Promise<Faculty>;
    getNews(id: bigint): Promise<News>;
    getNewsAll(): Promise<Array<News>>;
    getPlacements(): Promise<Array<Placement>>;
    getProgram(id: bigint): Promise<Program>;
    getPrograms(): Promise<Array<Program>>;
    getResearchCenters(): Promise<Array<ResearchCenter>>;
    getStatistics(): Promise<Statistics>;
}
