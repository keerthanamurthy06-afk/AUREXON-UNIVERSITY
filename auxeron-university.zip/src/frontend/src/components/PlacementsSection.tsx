import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useNavigate } from "@tanstack/react-router";
import { Quote, TrendingUp, Zap } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { usePlacements } from "../hooks/useQueries";

const placementStats = [
  { value: "12.5 LPA", label: "Average Package" },
  { value: "52 LPA", label: "Highest Package" },
  { value: "320+", label: "Companies Visited" },
  { value: "98%", label: "Students Placed" },
];

const recruiters = [
  { name: "Google", domain: "Technology" },
  { name: "Microsoft", domain: "Technology" },
  { name: "Amazon", domain: "E-Commerce" },
  { name: "Infosys", domain: "IT Services" },
  { name: "TCS", domain: "IT Services" },
  { name: "Wipro", domain: "IT Services" },
  { name: "L&T", domain: "Engineering" },
  { name: "ISRO", domain: "Space Agency" },
  { name: "DRDO", domain: "Defence" },
  { name: "Bosch", domain: "Automotive" },
  { name: "Siemens", domain: "Industry" },
  { name: "Intel", domain: "Semiconductors" },
];

const yearWise = [
  { year: "2020", placed: 82, avg: 8.2 },
  { year: "2021", placed: 87, avg: 9.0 },
  { year: "2022", placed: 91, avg: 10.2 },
  { year: "2023", placed: 95, avg: 11.5 },
  { year: "2024", placed: 97, avg: 12.1 },
  { year: "2025", placed: 98, avg: 12.5 },
];

const skillsList = [
  "JavaScript",
  "Python",
  "Java",
  "C++",
  "Machine Learning",
  "Data Science",
  "Cloud (AWS/GCP)",
  "React/Angular",
  "SQL/Databases",
  "Communication",
  "Aptitude",
  "DSA",
];

function calcPlacement(cgpa: number, skills: string[]) {
  let cgpaPoints = 10;
  if (cgpa >= 9) cgpaPoints = 50;
  else if (cgpa >= 8) cgpaPoints = 40;
  else if (cgpa >= 7) cgpaPoints = 30;
  else if (cgpa >= 6) cgpaPoints = 20;
  const skillPoints = Math.min(50, skills.length * 5);
  return Math.min(97, cgpaPoints + skillPoints);
}

function getTier(pct: number) {
  if (pct >= 90)
    return { label: "Excellent Profile", color: "text-emerald-600" };
  if (pct >= 75) return { label: "Strong Profile", color: "text-blue-600" };
  if (pct >= 50) return { label: "Good Prospects", color: "text-amber-600" };
  return { label: "Keep Improving", color: "text-red-500" };
}

function getBarColor(pct: number) {
  if (pct >= 75) return "bg-emerald-500";
  if (pct >= 50) return "bg-amber-400";
  return "bg-red-400";
}

function PlacementPredictor() {
  const [cgpa, setCgpa] = useState(7.5);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [result, setResult] = useState<number | null>(null);
  const [animating, setAnimating] = useState(false);

  function toggleSkill(skill: string) {
    setSelectedSkills((prev) =>
      prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill],
    );
  }

  function predict() {
    const pct = calcPlacement(cgpa, selectedSkills);
    setResult(null);
    setAnimating(true);
    setTimeout(() => {
      setResult(pct);
      setAnimating(false);
    }, 400);
  }

  const tier = result !== null ? getTier(result) : null;

  return (
    <div
      className="fade-in-up mb-10 bg-navy rounded-2xl p-8"
      data-ocid="placements.panel"
    >
      <div className="flex items-center gap-3 mb-6">
        <Zap className="w-7 h-7 text-gold" />
        <h3 className="font-display text-2xl font-bold text-white">
          Placement Predictor
        </h3>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Left: inputs */}
        <div>
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <Label className="text-white font-semibold text-base">
                Your CGPA
              </Label>
              <span className="text-gold font-bold text-xl">
                {cgpa.toFixed(1)}
              </span>
            </div>
            <Slider
              min={0}
              max={10}
              step={0.1}
              value={[cgpa]}
              onValueChange={(v) => setCgpa(v[0])}
              data-ocid="placements.toggle"
              className="[&>[role=slider]]:bg-gold [&>[role=slider]]:border-gold"
            />
            <div className="flex justify-between text-white/40 text-xs mt-1">
              <span>0.0</span>
              <span>5.0</span>
              <span>10.0</span>
            </div>
          </div>

          <div>
            <Label className="text-white font-semibold text-base mb-3 block">
              Select Your Skills
            </Label>
            <div className="grid grid-cols-2 gap-2">
              {skillsList.map((skill) => (
                <label
                  key={skill}
                  htmlFor={`skill-${skill}`}
                  className="flex items-center gap-2 bg-white/10 rounded-lg px-3 py-2 hover:bg-white/20 transition cursor-pointer"
                >
                  <Checkbox
                    id={`skill-${skill}`}
                    checked={selectedSkills.includes(skill)}
                    onCheckedChange={() => toggleSkill(skill)}
                    data-ocid="placements.checkbox"
                    className="border-white/40 data-[state=checked]:bg-gold data-[state=checked]:border-gold"
                  />
                  <span className="text-white/80 text-sm select-none">
                    {skill}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <Button
            onClick={predict}
            data-ocid="placements.primary_button"
            className="mt-6 w-full bg-gold hover:bg-gold-dark text-navy-dark font-bold text-base py-3 uppercase tracking-wide"
          >
            Predict My Chances
          </Button>
        </div>

        {/* Right: result */}
        <div className="flex flex-col items-center justify-center">
          <AnimatePresence mode="wait">
            {result !== null && !animating ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.85 }}
                transition={{ duration: 0.4 }}
                className="w-full"
              >
                <div className="text-center mb-6">
                  <div className="font-display text-7xl font-bold text-gold mb-2">
                    {result}%
                  </div>
                  <div className={`text-lg font-bold ${tier?.color ?? ""}`}>
                    {tier?.label}
                  </div>
                  <div className="text-white/60 text-sm mt-1">
                    Placement Probability
                  </div>
                </div>

                <div className="bg-white/10 rounded-xl p-4">
                  <div className="flex justify-between text-white/70 text-sm mb-2">
                    <span>0%</span>
                    <span>50%</span>
                    <span>100%</span>
                  </div>
                  <div className="relative h-5 bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full rounded-full ${getBarColor(result)}`}
                      initial={{ width: 0 }}
                      animate={{ width: `${result}%` }}
                      transition={{ duration: 1, ease: "easeOut" }}
                    />
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-white/10 rounded-lg p-2 text-center">
                      <div className="text-white/50">CGPA Score</div>
                      <div className="text-white font-bold">
                        {cgpa >= 9
                          ? 50
                          : cgpa >= 8
                            ? 40
                            : cgpa >= 7
                              ? 30
                              : cgpa >= 6
                                ? 20
                                : 10}{" "}
                        pts
                      </div>
                    </div>
                    <div className="bg-white/10 rounded-lg p-2 text-center">
                      <div className="text-white/50">Skills Score</div>
                      <div className="text-white font-bold">
                        {Math.min(50, selectedSkills.length * 5)} pts
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="placeholder"
                className="text-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="text-8xl mb-4">🎯</div>
                <p className="text-white/60 text-base">
                  Enter your CGPA and skills,
                  <br />
                  then click Predict My Chances
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

export function PlacementsSection() {
  const { data: placements } = usePlacements();
  const navigate = useNavigate();
  const ref = useRef<HTMLDivElement>(null);

  const displayStats =
    placements && placements.length > 0
      ? [
          {
            value: `${Math.round(placements.reduce((a, p) => a + p.package, 0) / placements.length)} LPA`,
            label: "Average Package",
          },
          {
            value: `${Math.max(...placements.map((p) => p.package))} LPA`,
            label: "Highest Package",
          },
          {
            value: `${new Set(placements.map((p) => p.company)).size}+`,
            label: "Companies Visited",
          },
          { value: "98%", label: "Students Placed" },
        ]
      : placementStats;

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        }
      },
      { threshold: 0.1 },
    );
    const els = ref.current?.querySelectorAll(".fade-in-up");
    if (els) {
      for (const el of els) observer.observe(el);
    }
    return () => observer.disconnect();
  }, []);

  return (
    <section id="placements" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
            Placements
          </h2>
          <p className="mt-8 text-muted-foreground text-lg max-w-2xl mx-auto">
            Industry-ready graduates powering the world's top organizations
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {displayStats.map((s, i) => (
            <div
              key={s.label}
              className="fade-in-up text-center p-6 rounded-xl bg-navy"
              style={{ transitionDelay: `${i * 0.1}s` }}
            >
              <div className="font-display text-4xl font-bold text-gold mb-2">
                {s.value}
              </div>
              <div className="text-white/70 text-sm font-semibold uppercase tracking-wider">
                {s.label}
              </div>
            </div>
          ))}
        </div>

        {/* Year-wise trend */}
        <div className="fade-in-up mb-16 bg-secondary rounded-xl p-8">
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-6 h-6 text-gold" />
            <h3 className="font-display text-2xl font-bold text-navy">
              Year-wise Placement Trend
            </h3>
          </div>
          <div className="flex items-end gap-3 sm:gap-4 h-40">
            {yearWise.map((y) => (
              <div
                key={y.year}
                className="flex-1 flex flex-col items-center gap-2"
              >
                <div className="text-xs font-bold text-navy">{y.placed}%</div>
                <div
                  className="w-full bg-navy rounded-t-sm transition-all"
                  style={{ height: `${(y.placed / 100) * 120}px` }}
                />
                <div className="text-xs text-muted-foreground font-semibold">
                  {y.year}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recruiters */}
        <div className="fade-in-up mb-16">
          <h3 className="font-display text-2xl font-bold text-navy mb-6 text-center">
            Top Recruiters
          </h3>
          <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-4">
            {recruiters.map((r, i) => (
              <div
                key={r.name}
                data-ocid={`placements.item.${i + 1}`}
                className="rounded-xl border border-border bg-white p-4 hover-lift text-center"
              >
                <div className="font-bold text-navy text-base mb-1">
                  {r.name}
                </div>
                <div className="text-muted-foreground text-xs">{r.domain}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Testimonial */}
        <div className="fade-in-up bg-navy rounded-2xl p-8 mb-10">
          <Quote className="w-10 h-10 text-gold/40 mb-4" />
          <p className="text-white text-lg leading-relaxed italic mb-6">
            "Aurexon University gave me more than just a degree \u2014 it gave
            me the skills, network, and confidence to land my dream job at
            Google. The faculty are world-class and the campus placement support
            is unmatched in India."
          </p>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gold flex items-center justify-center text-navy-dark font-bold text-lg">
              AK
            </div>
            <div>
              <div className="text-white font-bold">Arjun Kapoor</div>
              <div className="text-white/60 text-sm">
                Software Engineer, Google \u2022 B.Tech CSE, 2024
              </div>
            </div>
          </div>
        </div>

        {/* Placement Predictor */}
        <PlacementPredictor />

        {/* CTA */}
        <div className="text-center">
          <button
            type="button"
            onClick={() => navigate({ to: "/admissions" })}
            data-ocid="placements.secondary_button"
            className="bg-gold hover:bg-gold-dark text-navy-dark font-bold py-4 px-12 rounded-md text-lg uppercase tracking-wide transition-all hover:shadow-xl hover:-translate-y-0.5"
          >
            Start Your Journey \u2192 Apply Now
          </button>
        </div>
      </div>
    </section>
  );
}
