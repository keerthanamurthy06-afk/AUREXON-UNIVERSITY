import { ScrollArea } from "@/components/ui/scroll-area";
import { useNavigate } from "@tanstack/react-router";
import { MessageCircle, Mic, MicOff, Send, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useRef, useState } from "react";

interface Message {
  id: number;
  from: "bot" | "user";
  text: string;
}

function getBotReply(msg: string): string {
  const m = msg.toLowerCase();
  if (/admissions?|apply|application|2026/.test(m))
    return "Applications for 2026 batch are open! Visit the Admissions page. Eligibility: 10+2 with PCM 75%+. Apply at admissions@aurexon.edu";
  if (/fees?|cost|tuition/.test(m))
    return "Annual fees range from \u20b91,60,000 to \u20b91,90,000 depending on the department. Scholarships are available for merit students.";
  if (/departments?|courses?|programs?|branch/.test(m))
    return "We offer 11 engineering departments: Computer Science, Electronics, Mechanical, Civil, Electrical, Chemical, Aerospace, Biotechnology, Information Technology, AI & Data Science, and Industrial Engineering. Visit the Academics page to explore.";
  if (/placement|salary|package|job|recruit/.test(m))
    return "Our placement rate is 98%! Average package 12.5 LPA, highest 52 LPA. 320+ companies including Google, Microsoft, Amazon, and ISRO visit us.";
  if (/campus|hostel|facilities/.test(m))
    return "Aurexon has a 200-acre campus with Olympic-size sports complex, 4,000-seat hostel, 60+ clubs, innovation hub, and modern cafeterias.";
  if (/faculty|professor|teacher/.test(m))
    return "We have 850+ faculty members. 60% have international experience, 100+ PhDs from IITs and IISc.";
  if (/research|publication|patent/.test(m))
    return "500+ publications, \u20b950Cr+ funded projects, 45 patents filed. We have 5 specialized research centers.";
  if (/contact|email|phone|address/.test(m))
    return "Contact us at info@aurexon.edu or call +91-44-2358-0000. Visit us at Aurexon University, Chennai - 600025.";
  if (/scholarship|financial|aid/.test(m))
    return "Merit scholarships available for top 10% students. Fee waivers for economically disadvantaged students. Contact admissions for details.";
  if (/ranking|naac|accreditation/.test(m))
    return "Aurexon is NAAC A+ Accredited, ranked in top 50 engineering colleges in India. Established in 1974.";
  if (/hello|hi|hey/.test(m))
    return "Hello! Welcome to Aurexon University. How can I help you today?";
  return "I can answer questions about Aurexon University \u2014 admissions, fees, departments, placements, campus, faculty, and more. What would you like to know?";
}

type VoiceNavResult = { path: string; speech: string } | null;

function getVoiceNavigation(transcript: string): VoiceNavResult {
  const t = transcript.toLowerCase();
  if (/admissions?|apply now/.test(t))
    return {
      path: "/admissions",
      speech: "Sure! Opening the Admissions section for you right now.",
    };
  if (/placement/.test(t))
    return {
      path: "/placements",
      speech: "Taking you to the Placements page right away!",
    };
  if (/academics?|departments?/.test(t))
    return {
      path: "/#academics",
      speech: "Opening the Academics section for you!",
    };
  if (/research/.test(t))
    return { path: "/research", speech: "Opening the Research section!" };
  if (/campus|campus life/.test(t))
    return { path: "/campus", speech: "Opening Campus Life section!" };
  if (/contact/.test(t))
    return { path: "/contact", speech: "Opening the Contact section!" };
  if (/faculty/.test(t))
    return { path: "/faculty", speech: "Opening the Faculty section!" };
  if (/events?/.test(t))
    return { path: "/events", speech: "Opening the Events section!" };
  if (/^go home$|^home$/.test(t.trim()))
    return { path: "/", speech: "Taking you to the homepage!" };
  return null;
}

// Speech API helpers (using any to avoid lib.dom requirement)
const SpeechAPI: any =
  typeof window !== "undefined"
    ? (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition
    : null;

let msgId = 0;

export function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: ++msgId,
      from: "bot",
      text: "Hi! I'm the Aurexon University assistant. Ask me anything, or use the \ud83c\udf99\ufe0f voice button to navigate hands-free!",
    },
  ]);
  const [input, setInput] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const api =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (api) setSpeechSupported(true);
  }, []);

  // biome-ignore lint/correctness/useExhaustiveDependencies: scroll after message updates
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  function speak(text: string) {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.1;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  }

  function addMessages(userText: string, botText: string) {
    const userMsg: Message = { id: ++msgId, from: "user", text: userText };
    const botMsg: Message = { id: ++msgId, from: "bot", text: botText };
    setMessages((prev) => [...prev, userMsg, botMsg]);
  }

  function send() {
    const text = input.trim();
    if (!text) return;
    const reply = getBotReply(text);
    addMessages(text, reply);
    speak(reply);
    setInput("");
  }

  function handleKey(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  function startListening() {
    const api =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (!api) return;
    if (recognitionRef.current) recognitionRef.current.stop();

    const recognition = new api();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognitionRef.current = recognition;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);

    recognition.onresult = (event: any) => {
      const transcript: string = event.results[0][0].transcript;
      const navResult = getVoiceNavigation(transcript);

      if (navResult) {
        addMessages(transcript, navResult.speech);
        speak(navResult.speech);
        setTimeout(() => {
          if (navResult.path.startsWith("/#")) {
            navigate({ to: "/" });
            setTimeout(() => {
              const id = navResult.path.replace("/#", "");
              document
                .getElementById(id)
                ?.scrollIntoView({ behavior: "smooth" });
            }, 300);
          } else {
            navigate({ to: navResult.path as "/" });
          }
        }, 400);
      } else {
        const reply = getBotReply(transcript);
        addMessages(transcript, reply);
        speak(reply);
      }
    };

    recognition.start();
  }

  function stopListening() {
    recognitionRef.current?.stop();
    setIsListening(false);
  }

  function toggleMic() {
    if (isListening) {
      stopListening();
    } else {
      setOpen(true);
      startListening();
    }
  }

  // suppress unused warning
  void SpeechAPI;

  return (
    <div
      className="fixed bottom-6 right-6 z-[9999] flex flex-col items-end gap-3"
      data-ocid="chat.panel"
    >
      <AnimatePresence>
        {open && (
          <motion.div
            key="chat"
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="w-[360px] sm:w-[380px] h-[520px] bg-white rounded-2xl shadow-2xl border border-border flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div
              className="flex items-center justify-between px-5 py-4"
              style={{ background: "oklch(0.18 0.055 248)" }}
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gold flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-navy-dark" />
                </div>
                <div>
                  <div className="text-white font-bold text-sm">
                    Aurexon Assistant
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-white/60 text-xs">Ask or speak!</span>
                    {isSpeaking && (
                      <span className="text-xs text-gold animate-pulse">
                        \ud83d\udd0a Speaking...
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                data-ocid="chat.close_button"
                className="text-white/60 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 px-4 py-3">
              <div className="flex flex-col gap-3">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${
                      msg.from === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                        msg.from === "user"
                          ? "bg-navy text-white rounded-br-sm"
                          : "bg-secondary text-foreground rounded-bl-sm"
                      }`}
                    >
                      {msg.text}
                    </div>
                  </div>
                ))}
                <div ref={bottomRef} />
              </div>
            </ScrollArea>

            {/* Listening indicator */}
            {isListening && (
              <div className="px-4 py-1.5 bg-red-50 border-t border-red-100 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <span className="text-xs text-red-600 font-medium">
                  \ud83c\udf99\ufe0f Listening... speak your command
                </span>
              </div>
            )}

            {/* Hint bar */}
            {!isListening && (
              <div className="px-4 py-1 bg-navy/5 border-t border-navy/10">
                <p className="text-[10px] text-muted-foreground">
                  \ud83d\udca1 Try: \"Open Admissions\", \"Show Placements\",
                  \"Go Home\"
                </p>
              </div>
            )}

            {/* Input */}
            <div className="border-t border-border px-4 py-3 flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKey}
                placeholder="Type your question..."
                data-ocid="chat.input"
                className="flex-1 border border-border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-navy/30"
              />
              {speechSupported && (
                <button
                  type="button"
                  onClick={toggleMic}
                  data-ocid="chat.toggle"
                  title={isListening ? "Stop listening" : "Voice command"}
                  className={`rounded-xl px-3 py-2 transition ${
                    isListening
                      ? "bg-red-500 hover:bg-red-600 text-white animate-pulse"
                      : "bg-navy/10 hover:bg-navy/20 text-navy"
                  }`}
                >
                  {isListening ? (
                    <MicOff className="w-4 h-4" />
                  ) : (
                    <Mic className="w-4 h-4" />
                  )}
                </button>
              )}
              <button
                type="button"
                onClick={send}
                data-ocid="chat.submit_button"
                className="bg-navy hover:bg-navy/80 text-white rounded-xl px-3 py-2 transition"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toggle button */}
      <motion.button
        type="button"
        onClick={() => setOpen((o) => !o)}
        data-ocid="chat.open_modal_button"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="flex items-center gap-2 bg-gold text-navy-dark font-bold px-4 py-3 rounded-full shadow-xl hover:shadow-2xl transition-shadow"
      >
        <MessageCircle className="w-5 h-5" />
        <span className="text-sm">Need Help?</span>
      </motion.button>
    </div>
  );
}
