import { Award, CheckCircle, Globe, Users } from "lucide-react";
import { useEffect, useRef } from "react";

const features = [
  {
    icon: Award,
    title: "Research Excellence",
    desc: "500+ publications, ₹50Cr+ funded projects, 45 patents filed annually.",
  },
  {
    icon: Users,
    title: "Industry Partnerships",
    desc: "120+ industry partners including Google, ISRO, L&T, Siemens and more.",
  },
  {
    icon: Globe,
    title: "Global Alumni Network",
    desc: "30,000+ alumni across 60 countries driving innovation worldwide.",
  },
];

const accreditations = [
  "NAAC A+",
  "NBA Accredited",
  "NIRF Rank 28",
  "ISO 9001:2015",
  "AICTE Approved",
  "UGC Recognized",
];

export function AboutSection() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        }
      },
      { threshold: 0.1 },
    );
    const els = ref.current?.querySelectorAll(".fade-in-up");
    if (els) {
      for (const el of els) {
        observer.observe(el);
      }
    }
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
            About Aurexon
          </h2>
          <p className="mt-8 text-muted-foreground text-lg max-w-2xl mx-auto">
            A legacy of engineering excellence spanning five decades
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left: text */}
          <div className="fade-in-up">
            <div className="relative rounded-xl overflow-hidden mb-8">
              <img
                src="/assets/generated/campus-aerial.dim_800x500.jpg"
                alt="Aurexon University Campus"
                className="w-full h-72 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/50 to-transparent" />
              <div className="absolute bottom-4 left-4 text-white">
                <div className="font-display text-xl font-bold">
                  Main Campus
                </div>
                <div className="text-sm opacity-80">
                  NH-48, Tech Corridor, Bangalore
                </div>
              </div>
            </div>
            <h3 className="font-display text-2xl font-bold text-navy mb-4">
              Our Mission & Vision
            </h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Founded in 1974, Aurexon University has grown from a regional
              engineering college into one of India's most prestigious technical
              institutions. Our mission is to produce world-class engineers who
              drive technological innovation and social progress.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-6">
              We envision becoming a globally recognized center of engineering
              education and research by 2030, fostering a culture of innovation,
              entrepreneurship, and responsible technology development.
            </p>
            <div className="flex flex-col gap-3">
              {[
                "50 years of engineering excellence",
                "NAAC A+ Grade — highest accreditation",
                "NBA accredited programs across all departments",
                "Top 30 in NIRF Engineering Rankings",
              ].map((item) => (
                <div key={item} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-gold flex-shrink-0" />
                  <span className="text-sm font-medium text-foreground">
                    {item}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: features + accreditations */}
          <div className="space-y-8">
            {features.map((f, i) => (
              <div
                key={f.title}
                className="fade-in-up flex gap-5 p-5 rounded-xl bg-secondary hover-lift"
                style={{ transitionDelay: `${i * 0.15}s` }}
              >
                <div className="w-12 h-12 bg-navy rounded-lg flex items-center justify-center flex-shrink-0">
                  <f.icon className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h4 className="font-bold text-navy text-lg mb-1">
                    {f.title}
                  </h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {f.desc}
                  </p>
                </div>
              </div>
            ))}

            <div
              className="fade-in-up p-6 rounded-xl bg-navy"
              style={{ transitionDelay: "0.4s" }}
            >
              <h4 className="text-gold font-bold uppercase tracking-widest text-sm mb-4">
                Accreditations & Rankings
              </h4>
              <div className="flex flex-wrap gap-3">
                {accreditations.map((acc) => (
                  <span
                    key={acc}
                    className="bg-white/10 border border-white/20 text-white text-sm font-semibold px-4 py-1.5 rounded-full"
                  >
                    {acc}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
