import { useNavigate } from "@tanstack/react-router";
import { ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useEffect, useState } from "react";

const slides = [
  {
    id: 1,
    image: "/assets/generated/university-campus-1.dim_1920x1080.jpg",
    badge: "NAAC A+ Accredited — Est. 1974",
    title: "Shape the Future of",
    highlight: "Engineering",
    subtitle:
      "World-class education, cutting-edge research, and industry-ready graduates since 1974. Join 15,000+ students building tomorrow's world.",
    cta: "Explore Programs",
    ctaRoute: "/academics",
    secondaryCta: "Virtual Campus Tour",
    secondaryRoute: "/campus",
  },
  {
    id: 2,
    image: "/assets/generated/university-campus-2.dim_1920x1080.jpg",
    badge: "500+ International Publications",
    title: "World-Class",
    highlight: "Research",
    subtitle:
      "₹50 Crore+ in funded research projects, 45 patents filed, and 5 specialized research centres driving innovation across every discipline.",
    cta: "Discover Research",
    ctaRoute: "/research",
    secondaryCta: "Meet Our Faculty",
    secondaryRoute: "/faculty",
  },
  {
    id: 3,
    image: "/assets/generated/university-campus-3.dim_1920x1080.jpg",
    badge: "98% Placement Rate",
    title: "98% Placement",
    highlight: "Success Record",
    subtitle:
      "Average package of 12.5 LPA, highest 52 LPA. 320+ companies including Google, Microsoft, Amazon, and ISRO recruit from our campus every year.",
    cta: "View Placements",
    ctaRoute: "/placements",
    secondaryCta: "Apply Now",
    secondaryRoute: "/admissions",
  },
  {
    id: 4,
    image: "/assets/generated/university-campus-4.dim_1920x1080.jpg",
    badge: "98% Placement Rate • Top Recruiters",
    title: "Career-Ready",
    highlight: "Graduates",
    subtitle:
      "320+ companies recruit from our campus. Build your career with industry-aligned programs, live projects, and mentorship from top professionals.",
    cta: "View Placements",
    ctaRoute: "/placements",
    secondaryCta: "Apply Now",
    secondaryRoute: "/admissions",
  },
  {
    id: 5,
    image: "/assets/generated/university-campus-5.dim_1920x1080.jpg",
    badge: "Applications Open Now",
    title: "Apply for the",
    highlight: "2026 Batch",
    subtitle:
      "Seats filling fast. Eligibility: 10+2 with PCM 75%+. Join 8 departments, 30+ programs, and a legacy of excellence that shapes leaders.",
    cta: "Apply Now",
    ctaRoute: "/admissions",
    secondaryCta: "View Departments",
    secondaryRoute: "/academics",
  },
];

export function HeroSection() {
  const navigate = useNavigate();
  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(1);

  const goTo = useCallback((index: number, dir: number) => {
    setDirection(dir);
    setCurrent((index + slides.length) % slides.length);
  }, []);

  const next = useCallback(() => goTo(current + 1, 1), [current, goTo]);
  const prev = useCallback(() => goTo(current - 1, -1), [current, goTo]);

  useEffect(() => {
    const timer = setInterval(next, 4500);
    return () => clearInterval(timer);
  }, [next]);

  const slide = slides[current];

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      {/* Background images with cross-fade */}
      <AnimatePresence initial={false} mode="sync">
        <motion.div
          key={slide.id}
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${slide.image})` }}
          initial={{ opacity: 0, scale: 1.04 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.0 }}
        />
      </AnimatePresence>

      {/* Dimming overlay — reduces image brightness so text reads clearly */}
      <div className="absolute inset-0 bg-white/55" />
      {/* Subtle bottom gradient for depth */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-200/60 via-transparent to-transparent" />

      {/* Slide content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 pt-40 w-full">
        <AnimatePresence mode="wait">
          <motion.div
            key={slide.id}
            initial={{ opacity: 0, x: direction * 60 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: direction * -60 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="max-w-4xl"
          >
            <div className="inline-flex items-center gap-2 bg-navy-dark/10 border border-navy-dark/25 rounded-full px-4 py-1.5 mb-6">
              <span className="w-2 h-2 rounded-full bg-navy-dark animate-pulse" />
              <span className="text-navy-dark text-sm font-semibold tracking-wider uppercase">
                {slide.badge}
              </span>
            </div>

            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-slate-800 leading-tight mb-6">
              {slide.title}
              <span className="block text-blue-900">{slide.highlight}</span>
            </h1>

            <p className="text-slate-700 text-lg sm:text-xl max-w-2xl mb-10 leading-relaxed font-medium">
              {slide.subtitle}
            </p>

            <div className="flex flex-wrap gap-4">
              <button
                type="button"
                onClick={() => navigate({ to: slide.ctaRoute as "/" })}
                data-ocid="hero.primary_button"
                className="bg-blue-900 hover:bg-blue-800 text-white font-bold py-3 px-8 rounded-md text-base uppercase tracking-wide transition-all hover:shadow-xl hover:-translate-y-0.5"
              >
                {slide.cta}
              </button>
              <button
                type="button"
                onClick={() => navigate({ to: slide.secondaryRoute as "/" })}
                data-ocid="hero.secondary_button"
                className="border-2 border-blue-900 text-blue-900 hover:bg-blue-900 hover:text-white font-bold py-3 px-8 rounded-md text-base uppercase tracking-wide transition-all"
              >
                {slide.secondaryCta}
              </button>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Prev / Next arrows */}
      <button
        type="button"
        onClick={prev}
        data-ocid="hero.pagination_prev"
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-slate-800/20 hover:bg-slate-800/40 border border-slate-700/30 rounded-full p-3 text-slate-800 transition-all"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button
        type="button"
        onClick={next}
        data-ocid="hero.pagination_next"
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-slate-800/20 hover:bg-slate-800/40 border border-slate-700/30 rounded-full p-3 text-slate-800 transition-all"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Dot indicators */}
      <div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {slides.map((s, i) => (
          <button
            key={s.id}
            type="button"
            onClick={() => goTo(i, i > current ? 1 : -1)}
            data-ocid="hero.toggle"
            className={`w-2.5 h-2.5 rounded-full transition-all ${
              i === current
                ? "bg-blue-900 scale-125"
                : "bg-slate-600/50 hover:bg-slate-700/70"
            }`}
          />
        ))}
      </div>

      {/* Scroll indicator */}
      <button
        type="button"
        onClick={() => {
          const el = document.getElementById("stats");
          if (el) el.scrollIntoView({ behavior: "smooth" });
        }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-slate-700 hover:text-slate-900 animate-bounce transition-colors z-20"
      >
        <ChevronDown className="w-8 h-8" />
      </button>
    </section>
  );
}
