import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

const departments = [
  "Computer Science & Engineering",
  "Electronics & Communication Engineering",
  "Mechanical Engineering",
  "Civil Engineering",
  "Electrical Engineering",
  "Chemical Engineering",
  "Aerospace Engineering",
  "Biotechnology Engineering",
];

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    department: "",
    message: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        }
      },
      { threshold: 0.1 },
    );
    const els = ref.current?.querySelectorAll(".fade-in-up");
    if (els) {
      for (const el of els) observer.observe(el);
    }
    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const subject = encodeURIComponent(`Inquiry from ${formData.name}`);
    const body = encodeURIComponent(
      `Name: ${formData.name}\nEmail: ${formData.email}\nPhone: ${formData.phone || "N/A"}\nDepartment Interested: ${formData.department || "N/A"}\n\nMessage:\n${formData.message}`,
    );
    window.location.href = `mailto:contact@aurexon.edu?subject=${subject}&body=${body}`;
    setTimeout(() => {
      setSubmitting(false);
      toast.success(
        "Email client opened! Please send the email to complete your inquiry.",
      );
      setFormData({
        name: "",
        email: "",
        phone: "",
        department: "",
        message: "",
      });
    }, 500);
  };

  return (
    <section id="contact" className="py-20 bg-secondary" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
            Contact Us
          </h2>
          <p className="mt-8 text-muted-foreground text-lg max-w-2xl mx-auto">
            We're here to help. Reach out to our admissions team today.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left: Info */}
          <div className="fade-in-up space-y-6">
            <div className="bg-white rounded-xl p-6 shadow-card">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-navy rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-navy text-lg mb-1">Address</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Aurexon University,
                    <br />
                    NH-48, Tech Corridor,
                    <br />
                    Devanahalli, Bangalore — 560 100
                    <br />
                    Karnataka, India
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-card">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-navy rounded-lg flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-navy text-lg mb-1">Phone</h3>
                  <p className="text-muted-foreground text-sm">
                    +91-80-4567-8900 (Main)
                  </p>
                  <p className="text-muted-foreground text-sm">
                    +91-80-4567-8901 (Admissions)
                  </p>
                  <p className="text-muted-foreground text-sm">
                    +91-80-4567-8902 (Research)
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-card">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-navy rounded-lg flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-navy text-lg mb-1">Email</h3>
                  <p className="text-muted-foreground text-sm">
                    admissions@aurexon.edu
                  </p>
                  <p className="text-muted-foreground text-sm">
                    research@aurexon.edu
                  </p>
                  <p className="text-muted-foreground text-sm">
                    placements@aurexon.edu
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-card">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-navy rounded-lg flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-navy text-lg mb-1">
                    Working Hours
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    Mon–Fri: 9:00 AM – 5:00 PM
                  </p>
                  <p className="text-muted-foreground text-sm">
                    Saturday: 9:00 AM – 1:00 PM
                  </p>
                  <p className="text-muted-foreground text-sm">
                    Sunday: Closed
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Form */}
          <div className="fade-in-up" style={{ transitionDelay: "0.2s" }}>
            <div className="bg-white rounded-xl p-8 shadow-card">
              <h3 className="font-display text-2xl font-bold text-navy mb-6">
                Send us a Message
              </h3>
              <form
                onSubmit={handleSubmit}
                className="space-y-5"
                data-ocid="contact.modal"
              >
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label
                      htmlFor="contact-name"
                      className="text-sm font-semibold text-navy"
                    >
                      Full Name *
                    </Label>
                    <Input
                      id="contact-name"
                      required
                      data-ocid="contact.input"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData((p) => ({ ...p, name: e.target.value }))
                      }
                      placeholder="Your full name"
                      className="border-border focus:ring-gold"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label
                      htmlFor="contact-email"
                      className="text-sm font-semibold text-navy"
                    >
                      Email Address *
                    </Label>
                    <Input
                      id="contact-email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) =>
                        setFormData((p) => ({ ...p, email: e.target.value }))
                      }
                      placeholder="your@email.com"
                      className="border-border"
                    />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label
                      htmlFor="contact-phone"
                      className="text-sm font-semibold text-navy"
                    >
                      Phone Number
                    </Label>
                    <Input
                      id="contact-phone"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData((p) => ({ ...p, phone: e.target.value }))
                      }
                      placeholder="+91 XXXXX XXXXX"
                      className="border-border"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold text-navy">
                      Department Interested
                    </Label>
                    <Select
                      value={formData.department}
                      onValueChange={(v) =>
                        setFormData((p) => ({ ...p, department: v }))
                      }
                    >
                      <SelectTrigger
                        data-ocid="contact.select"
                        className="border-border"
                      >
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((d) => (
                          <SelectItem key={d} value={d}>
                            {d}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label
                    htmlFor="contact-message"
                    className="text-sm font-semibold text-navy"
                  >
                    Message *
                  </Label>
                  <Textarea
                    id="contact-message"
                    required
                    data-ocid="contact.textarea"
                    value={formData.message}
                    onChange={(e) =>
                      setFormData((p) => ({ ...p, message: e.target.value }))
                    }
                    placeholder="Tell us about your inquiry..."
                    rows={4}
                    className="border-border resize-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  data-ocid="contact.submit_button"
                  className="w-full bg-gold hover:bg-gold-dark text-navy-dark font-bold py-3 px-8 rounded-md text-sm uppercase tracking-wide transition-all disabled:opacity-60"
                >
                  {submitting ? "Opening Email..." : "Send Message"}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
