import { useNavigate } from "@tanstack/react-router";
import { Atom, Bot, FlaskConical, Heart, Zap } from "lucide-react";
import { useEffect, useRef } from "react";
import { useResearchCenters } from "../hooks/useQueries";

const fallbackCenters = [
  {
    id: 1n,
    name: "Centre for AI & Machine Learning",
    description:
      "Pioneering research in deep learning, NLP, computer vision, and autonomous systems with industry partnerships.",
    focusAreas: ["Deep Learning", "NLP", "Computer Vision"],
    facultyMembers: [],
  },
  {
    id: 2n,
    name: "Robotics & Automation Lab",
    description:
      "Advanced robotics systems, industrial automation, swarm robotics and human-robot interaction research.",
    focusAreas: ["Industrial Robotics", "Swarm Systems", "HRI"],
    facultyMembers: [],
  },
  {
    id: 3n,
    name: "Renewable Energy Research Centre",
    description:
      "Solar, wind, hydrogen fuel cells and smart grid technologies for a sustainable energy future.",
    focusAreas: ["Solar Energy", "Wind Power", "Hydrogen Cells"],
    facultyMembers: [],
  },
  {
    id: 4n,
    name: "Biomedical Engineering Lab",
    description:
      "Biosensors, medical imaging, prosthetics, and point-of-care diagnostics for healthcare innovation.",
    focusAreas: ["Biosensors", "Medical Imaging", "Prosthetics"],
    facultyMembers: [],
  },
  {
    id: 5n,
    name: "Smart Materials & Nanotechnology",
    description:
      "Nanocomposites, shape-memory alloys, photonic crystals and advanced manufacturing at the nanoscale.",
    focusAreas: ["Nanocomposites", "Photonics", "Manufacturing"],
    facultyMembers: [],
  },
];

const centerIcons = [FlaskConical, Bot, Zap, Heart, Atom];

const researchStats = [
  { value: "500+", label: "Publications" },
  { value: "₹50Cr+", label: "Funded Projects" },
  { value: "120+", label: "Industry Partners" },
  { value: "45", label: "Patents Filed" },
];

export function ResearchSection() {
  const { data: centers } = useResearchCenters();
  const displayCenters =
    centers && centers.length > 0 ? centers : fallbackCenters;
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        }
      },
      { threshold: 0.1 },
    );
    const els = ref.current?.querySelectorAll(".fade-in-up");
    if (els) {
      for (const el of els) observer.observe(el);
    }
    return () => observer.disconnect();
  }, []);

  return (
    <section id="research" className="py-20 bg-secondary" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
            Research
          </h2>
          <p className="mt-8 text-muted-foreground text-lg max-w-2xl mx-auto">
            Pushing the frontiers of knowledge across engineering disciplines
          </p>
        </div>

        <div className="relative rounded-xl overflow-hidden mb-12">
          <img
            src="/assets/generated/research-lab.dim_600x400.jpg"
            alt="Research Laboratory"
            className="w-full h-48 sm:h-64 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-navy/80 to-navy/40 flex items-center">
            <div className="px-8 sm:px-16">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                {researchStats.map((s) => (
                  <div key={s.label} className="text-center sm:text-left">
                    <div className="font-display text-3xl sm:text-4xl font-bold text-gold">
                      {s.value}
                    </div>
                    <div className="text-white/80 text-sm font-semibold uppercase tracking-wider">
                      {s.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {displayCenters.map((center, i) => {
            const Icon = centerIcons[i % centerIcons.length];
            return (
              <div
                key={String(center.id)}
                className="fade-in-up bg-white rounded-xl p-6 shadow-card hover-lift"
                style={{ transitionDelay: `${i * 0.1}s` }}
                data-ocid={`research.item.${i + 1}`}
              >
                <div className="w-12 h-12 bg-navy rounded-lg flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-gold" />
                </div>
                <h3 className="font-bold text-navy text-lg mb-3 leading-snug">
                  {center.name}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                  {center.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {center.focusAreas.map((area) => (
                    <span
                      key={area}
                      className="bg-secondary text-navy text-xs font-semibold px-3 py-1 rounded-full"
                    >
                      {area}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Collaborate CTA */}
        <div className="fade-in-up bg-navy rounded-2xl p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="font-display text-2xl font-bold text-white mb-2">
              Collaborate With Us
            </h3>
            <p className="text-white/70 text-sm max-w-lg">
              Partner with Aurexon's research teams on industry-sponsored
              projects, PhD programs, and joint publications.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate({ to: "/contact" })}
            data-ocid="research.primary_button"
            className="flex-shrink-0 bg-gold hover:bg-gold-dark text-navy-dark font-bold py-3 px-8 rounded-md text-sm uppercase tracking-wide transition-all hover:shadow-lg"
          >
            Get in Touch
          </button>
        </div>
      </div>
    </section>
  );
}
