import { useLocation, useNavigate } from "@tanstack/react-router";
import { Menu, Shield, X } from "lucide-react";
import { useEffect, useState } from "react";

const navLinks = [
  { label: "Home", path: "/" },
  { label: "About", path: "/about" },
  { label: "Academics", path: "/academics" },
  { label: "Admissions", path: "/admissions" },
  { label: "Research", path: "/research" },
  { label: "Campus Life", path: "/campus" },
  { label: "Events", path: "/events" },
  { label: "Placements", path: "/placements" },
  { label: "Contact", path: "/contact" },
];

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const goTo = (path: string) => {
    navigate({ to: path });
    setMenuOpen(false);
  };

  const isActive = (path: string) =>
    path === "/"
      ? location.pathname === "/"
      : location.pathname.startsWith(path);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "shadow-md" : ""
      } bg-white`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <button
            type="button"
            onClick={() => goTo("/")}
            className="flex items-center gap-3 group"
            data-ocid="header.link"
          >
            <div className="w-10 h-10 bg-navy rounded-md flex items-center justify-center flex-shrink-0 group-hover:bg-navy-mid transition-colors">
              <Shield className="w-6 h-6 text-gold" />
            </div>
            <div className="leading-tight">
              <div className="font-display font-bold text-navy text-lg tracking-wide leading-none">
                AUREXON
              </div>
              <div className="text-xs font-body text-navy/60 tracking-widest uppercase">
                University
              </div>
            </div>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                type="button"
                key={link.path}
                onClick={() => goTo(link.path)}
                data-ocid="header.link"
                className={`px-3 py-2 text-sm font-semibold tracking-wide uppercase transition-colors rounded-md ${
                  isActive(link.path)
                    ? "text-gold"
                    : "text-navy hover:text-gold"
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* CTA + Mobile menu */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => goTo("/admissions")}
              data-ocid="header.primary_button"
              className="hidden sm:block bg-gold hover:bg-gold-dark text-navy-dark font-bold py-2 px-5 rounded-md text-sm uppercase tracking-wide transition-all hover:shadow-md"
            >
              Apply Now
            </button>
            <button
              type="button"
              className="lg:hidden p-2 text-navy"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Toggle menu"
            >
              {menuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="lg:hidden bg-white border-t border-border shadow-lg">
          <nav className="px-4 py-4 space-y-1">
            {navLinks.map((link) => (
              <button
                type="button"
                key={link.path}
                onClick={() => goTo(link.path)}
                className="block w-full text-left px-4 py-2 text-sm font-semibold text-navy hover:text-gold hover:bg-secondary rounded-md uppercase tracking-wide transition-colors"
              >
                {link.label}
              </button>
            ))}
            <button
              type="button"
              onClick={() => goTo("/admissions")}
              className="w-full mt-2 bg-gold hover:bg-gold-dark text-navy-dark font-bold py-2 px-5 rounded-md text-sm uppercase tracking-wide transition-all"
            >
              Apply Now
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
