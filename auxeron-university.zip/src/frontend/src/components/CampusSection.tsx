import {
  BookOpen,
  Coffee,
  Cross,
  Dumbbell,
  Home,
  Lightbulb,
} from "lucide-react";
import { useEffect, useRef } from "react";

const facilities = [
  {
    icon: BookOpen,
    name: "Central Library",
    desc: "2 million+ books, 50,000+ e-journals, 24/7 access, digital reading rooms.",
    color: "bg-blue-50",
  },
  {
    icon: Dumbbell,
    name: "Sports Complex",
    desc: "Olympic-size pool, indoor stadium, cricket ground, tennis and badminton courts.",
    color: "bg-green-50",
  },
  {
    icon: Home,
    name: "Hostel Facilities",
    desc: "Fully furnished accommodation for 4,000 students with Wi-Fi, mess and laundry.",
    color: "bg-purple-50",
  },
  {
    icon: Coffee,
    name: "Cafeteria & Food Courts",
    desc: "6 dining venues serving South Indian, North Indian, Chinese and continental cuisine.",
    color: "bg-yellow-50",
  },
  {
    icon: Lightbulb,
    name: "Innovation Hub",
    desc: "State-of-the-art maker space with 3D printers, CNC machines and startup incubators.",
    color: "bg-orange-50",
  },
  {
    icon: Cross,
    name: "Medical Centre",
    desc: "24/7 healthcare with full-time doctors, pharmacy, ambulance and specialist visits.",
    color: "bg-red-50",
  },
];

const clubCategories = [
  {
    name: "Technical",
    clubs: ["Coding Club", "Robotics Club", "Astronomy Club", "AI/ML Society"],
  },
  {
    name: "Cultural",
    clubs: ["Drama Society", "Music Club", "Dance Troupe", "Film Making Club"],
  },
  {
    name: "Sports",
    clubs: ["Cricket Team", "Football Team", "Basketball Team", "Athletics"],
  },
  {
    name: "Social",
    clubs: ["NSS Unit", "Eco Club", "Photography Club", "Debate Society"],
  },
];

export function CampusSection() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        }
      },
      { threshold: 0.1 },
    );
    const els = ref.current?.querySelectorAll(".fade-in-up");
    if (els) {
      for (const el of els) {
        observer.observe(el);
      }
    }
    return () => observer.disconnect();
  }, []);

  return (
    <section id="campus" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
            Campus Life
          </h2>
          <p className="mt-8 text-muted-foreground text-lg max-w-2xl mx-auto">
            A vibrant campus that nurtures learning, creativity and holistic
            development
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {facilities.map((f, i) => (
            <div
              key={f.name}
              className={`fade-in-up rounded-xl p-6 ${f.color} hover-lift`}
              style={{ transitionDelay: `${i * 0.08}s` }}
              data-ocid={`campus.item.${i + 1}`}
            >
              <div className="w-12 h-12 bg-navy rounded-lg flex items-center justify-center mb-4">
                <f.icon className="w-6 h-6 text-gold" />
              </div>
              <h3 className="font-bold text-navy text-lg mb-2">{f.name}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {f.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Student Clubs */}
        <div className="fade-in-up bg-navy rounded-2xl p-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
            <div>
              <h3 className="font-display text-2xl font-bold text-white mb-1">
                Student Clubs & Activities
              </h3>
              <p className="text-white/60 text-sm">
                60+ clubs • Annual Techfest • Cultural Fest Aurex-Con
              </p>
            </div>
            <div className="mt-4 sm:mt-0 bg-gold text-navy-dark font-bold py-2 px-6 rounded-md text-sm uppercase tracking-wide">
              60+ Clubs
            </div>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {clubCategories.map((cat) => (
              <div key={cat.name}>
                <div className="text-gold font-bold text-sm uppercase tracking-widest mb-3">
                  {cat.name}
                </div>
                <ul className="space-y-2">
                  {cat.clubs.map((club) => (
                    <li
                      key={club}
                      className="text-white/80 text-sm flex items-center gap-2"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-gold/60" />
                      {club}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
