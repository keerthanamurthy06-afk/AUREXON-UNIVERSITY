import { useNavigate } from "@tanstack/react-router";
import { CheckCircle, Mail, MapPin, Phone, Shield } from "lucide-react";
import { useState } from "react";
import {
  SiFacebook,
  SiInstagram,
  SiLinkedin,
  SiX,
  SiYoutube,
} from "react-icons/si";

const quickLinks = [
  { label: "Home", path: "/" },
  { label: "About Us", path: "/about" },
  { label: "Academics", path: "/academics" },
  { label: "Admissions", path: "/admissions" },
  { label: "Research", path: "/research" },
  { label: "Campus Life", path: "/campus" },
  { label: "Placements", path: "/placements" },
  { label: "Contact", path: "/contact" },
];

const depts = [
  "Computer Science & Engg",
  "Electronics & Comm",
  "Mechanical Engg",
  "Civil Engg",
  "Electrical Engg",
  "Chemical Engg",
  "Aerospace Engg",
  "Biotechnology Engg",
];

export function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);
  const year = new Date().getFullYear();
  const navigate = useNavigate();

  const handleSubscribe = () => {
    if (!email.trim()) return;
    setSubscribed(true);
  };

  return (
    <footer className="bg-navy-dark text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Column 1: Logo + info */}
          <div>
            <button
              type="button"
              onClick={() => navigate({ to: "/" })}
              className="flex items-center gap-3 mb-5"
            >
              <div className="w-10 h-10 bg-gold rounded-md flex items-center justify-center">
                <Shield className="w-6 h-6 text-navy-dark" />
              </div>
              <div>
                <div className="font-display font-bold text-white text-lg leading-none">
                  AUREXON
                </div>
                <div className="text-xs text-white/50 tracking-widest uppercase">
                  University
                </div>
              </div>
            </button>
            <p className="text-white/60 text-sm leading-relaxed mb-5">
              Shaping engineers and innovators since 1974. NAAC A+ accredited
              institution committed to excellence.
            </p>
            <div className="space-y-2 text-sm text-white/60">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0 text-gold" />
                <span>NH-48, Tech Corridor, Bangalore – 560 100</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0 text-gold" />
                <span>+91-80-4567-8900</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 flex-shrink-0 text-gold" />
                <span>admissions@aurexon.edu</span>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              {[
                { Icon: SiFacebook, href: "#", name: "facebook" },
                { Icon: SiX, href: "#", name: "x" },
                { Icon: SiLinkedin, href: "#", name: "linkedin" },
                { Icon: SiYoutube, href: "#", name: "youtube" },
                { Icon: SiInstagram, href: "#", name: "instagram" },
              ].map(({ Icon: SocialIcon, href, name }) => (
                <a
                  key={name}
                  href={href}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-gold flex items-center justify-center transition-colors"
                >
                  <SocialIcon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="font-bold text-gold uppercase tracking-widest text-sm mb-5">
              Quick Links
            </h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <button
                    type="button"
                    onClick={() => navigate({ to: link.path })}
                    data-ocid="footer.link"
                    className="text-white/60 hover:text-gold text-sm transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Departments */}
          <div>
            <h4 className="font-bold text-gold uppercase tracking-widest text-sm mb-5">
              Departments
            </h4>
            <ul className="space-y-2">
              {depts.map((d) => (
                <li key={d}>
                  <button
                    type="button"
                    onClick={() => navigate({ to: "/academics" })}
                    className="text-white/60 hover:text-gold text-sm transition-colors text-left"
                  >
                    {d}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Newsletter */}
          <div>
            <h4 className="font-bold text-gold uppercase tracking-widest text-sm mb-5">
              Stay Updated
            </h4>
            <p className="text-white/60 text-sm mb-4">
              Subscribe to our newsletter for admissions news, events, and
              research updates.
            </p>

            {subscribed ? (
              <div className="bg-white/10 border border-gold/40 rounded-xl p-4 flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-semibold text-sm">
                    You're subscribed!
                  </p>
                  <p className="text-white/60 text-xs mt-0.5">
                    Thank you for subscribing. You'll receive the latest news,
                    events, and admissions updates from Aurexon University.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  data-ocid="footer.input"
                  className="w-full bg-white/10 border border-white/20 rounded-md px-4 py-2.5 text-sm text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-gold"
                />
                <button
                  type="button"
                  onClick={handleSubscribe}
                  data-ocid="footer.primary_button"
                  className="w-full bg-gold hover:bg-gold-dark text-navy-dark font-bold py-2.5 rounded-md text-sm uppercase tracking-wide transition-colors"
                >
                  Subscribe
                </button>
              </div>
            )}

            <div className="mt-6">
              <div className="text-xs text-white/40 uppercase tracking-widest mb-2">
                Accreditations
              </div>
              <div className="flex flex-wrap gap-2">
                {["NAAC A+", "NBA", "NIRF 28"].map((a) => (
                  <span
                    key={a}
                    className="text-xs bg-white/10 border border-white/20 px-3 py-1 rounded-full text-white/70"
                  >
                    {a}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/50 text-sm">
            © {year} Aurexon University. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <button
              type="button"
              className="text-white/50 hover:text-gold transition-colors"
            >
              Privacy Policy
            </button>
            <button
              type="button"
              className="text-white/50 hover:text-gold transition-colors"
            >
              Terms of Use
            </button>
            <button
              type="button"
              className="text-white/50 hover:text-gold transition-colors"
            >
              Sitemap
            </button>
          </div>
          <p className="text-white/40 text-xs">
            Built with ❤️ using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-gold hover:underline"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
