import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  CheckCircle,
  ClipboardCheck,
  FileText,
  FolderCheck,
  GraduationCap,
  Send,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";

const steps = [
  {
    icon: FileText,
    step: "01",
    title: "Apply Online",
    desc: "Fill the application form at aurexon.edu/apply with academic details.",
  },
  {
    icon: ClipboardCheck,
    step: "02",
    title: "Entrance Exam",
    desc: "Appear for JEE Main / GATE or Aurexon's own entrance examination.",
  },
  {
    icon: FolderCheck,
    step: "03",
    title: "Document Verification",
    desc: "Submit originals: 10th, 12th, entrance scorecard, category certificate.",
  },
  {
    icon: GraduationCap,
    step: "04",
    title: "Enrollment",
    desc: "Pay fees and complete enrollment formalities to secure your seat.",
  },
];

const eligibility = [
  {
    program: "B.Tech",
    qualification: "10+2 PCM",
    min: "60% marks",
    entrance: "JEE Main / AU-EEE",
  },
  {
    program: "M.Tech",
    qualification: "B.Tech / B.E.",
    min: "60% marks",
    entrance: "GATE / AU-PGEE",
  },
  {
    program: "Ph.D",
    qualification: "M.Tech / M.Sc",
    min: "55% marks",
    entrance: "NET / GATE / AU-RET",
  },
];

const dates = [
  { event: "Application Opens", date: "April 1, 2026" },
  { event: "Last Date to Apply", date: "May 5, 2026" },
  { event: "Entrance Exam", date: "May 15, 2026" },
  { event: "Results Declaration", date: "June 10, 2026" },
  { event: "Enrollment Begins", date: "July 1, 2026" },
];

const fees = [
  {
    program: "B.Tech",
    annual: "₹1,85,000",
    hostel: "₹72,000",
    total: "₹2,57,000",
  },
  {
    program: "M.Tech",
    annual: "₹1,20,000",
    hostel: "₹72,000",
    total: "₹1,92,000",
  },
  { program: "Ph.D", annual: "₹80,000", hostel: "₹72,000", total: "₹1,52,000" },
];

const programs = ["B.Tech", "M.Tech", "Ph.D"];
const departments = [
  "Computer Science & Engineering",
  "Electronics & Communication Engineering",
  "Mechanical Engineering",
  "Civil Engineering",
  "Electrical Engineering",
  "Chemical Engineering",
  "Aerospace Engineering",
  "Biotechnology Engineering",
];

function ApplyModal({ onClose }: { onClose: () => void }) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    program: "",
    department: "",
    sop: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(
      `Application: ${formData.program} - ${formData.name}`,
    );
    const dateStr = new Date().toLocaleDateString("en-IN", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
    const bodyText = `AUREXON UNIVERSITY - APPLICATION FORM\n=====================================\n\nFull Name: ${formData.name}\nEmail Address: ${formData.email}\nPhone Number: ${formData.phone}\nProgram Applied: ${formData.program}\nDepartment: ${formData.department}\n\nStatement of Purpose:\n${formData.sop}\n\nSubmitted on: ${dateStr}`;
    const body = encodeURIComponent(bodyText);
    window.location.href = `mailto:admissions@aurexon.edu?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0,0,0,0.6)" }}
      role="presentation"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      onKeyDown={(e) => {
        if (e.key === "Escape") onClose();
      }}
    >
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-navy text-white flex items-center justify-between px-6 py-4 rounded-t-2xl">
          <div>
            <h2 className="font-display text-xl font-bold">Apply Now — 2026</h2>
            <p className="text-white/60 text-sm">
              Aurexon University Admissions
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6">
          {submitted ? (
            <div className="text-center py-10">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="font-display text-2xl font-bold text-navy mb-3">
                Application Submitted!
              </h3>
              <p className="text-muted-foreground mb-2">
                Your email client has opened with your application pre-filled.
              </p>
              <p className="text-muted-foreground mb-6">
                Please click <strong>Send</strong> in your email app to complete
                the submission to <strong>admissions@aurexon.edu</strong>.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="bg-gold hover:bg-gold-dark text-navy-dark font-bold py-2.5 px-8 rounded-lg text-sm uppercase tracking-wide transition-colors"
              >
                Close
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label
                    htmlFor="m-name"
                    className="text-sm font-bold text-navy"
                  >
                    Full Name *
                  </Label>
                  <Input
                    id="m-name"
                    required
                    value={formData.name}
                    onChange={(e) =>
                      setFormData((p) => ({ ...p, name: e.target.value }))
                    }
                    placeholder="e.g. Rahul Sharma"
                  />
                </div>
                <div className="space-y-2">
                  <Label
                    htmlFor="m-email"
                    className="text-sm font-bold text-navy"
                  >
                    Email Address *
                  </Label>
                  <Input
                    id="m-email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) =>
                      setFormData((p) => ({ ...p, email: e.target.value }))
                    }
                    placeholder="your@gmail.com"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label
                    htmlFor="m-phone"
                    className="text-sm font-bold text-navy"
                  >
                    Phone Number *
                  </Label>
                  <Input
                    id="m-phone"
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData((p) => ({ ...p, phone: e.target.value }))
                    }
                    placeholder="+91 XXXXX XXXXX"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-bold text-navy">
                    Select Program *
                  </Label>
                  <Select
                    required
                    value={formData.program}
                    onValueChange={(v) =>
                      setFormData((p) => ({ ...p, program: v }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="B.Tech / M.Tech / Ph.D" />
                    </SelectTrigger>
                    <SelectContent>
                      {programs.map((prog) => (
                        <SelectItem key={prog} value={prog}>
                          {prog}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-bold text-navy">
                  Select Department *
                </Label>
                <Select
                  required
                  value={formData.department}
                  onValueChange={(v) =>
                    setFormData((p) => ({ ...p, department: v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose your department" />
                  </SelectTrigger>
                  <SelectContent>
                    {departments.map((dept) => (
                      <SelectItem key={dept} value={dept}>
                        {dept}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="m-sop" className="text-sm font-bold text-navy">
                  Statement of Purpose *
                </Label>
                <Textarea
                  id="m-sop"
                  required
                  value={formData.sop}
                  onChange={(e) =>
                    setFormData((p) => ({ ...p, sop: e.target.value }))
                  }
                  placeholder="Tell us about yourself, your academic background, and why you want to join Aurexon University..."
                  rows={4}
                  className="resize-none"
                />
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
                Clicking Submit will open your email client (Gmail, Outlook,
                etc.) with all details pre-filled. Just click{" "}
                <strong>Send</strong> to complete your application.
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-3 bg-gold hover:bg-gold-dark text-navy-dark font-bold py-4 px-8 rounded-xl text-base uppercase tracking-wide transition-all hover:shadow-xl hover:-translate-y-0.5"
              >
                <Send className="w-5 h-5" />
                Submit Application
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export function AdmissionsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        }
      },
      { threshold: 0.1 },
    );
    const els = ref.current?.querySelectorAll(".fade-in-up");
    if (els) {
      for (const el of els) observer.observe(el);
    }
    return () => observer.disconnect();
  }, []);

  return (
    <section id="admissions" className="py-20 bg-white" ref={ref}>
      {showModal && <ApplyModal onClose={() => setShowModal(false)} />}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
            Admissions
          </h2>
          <p className="mt-8 text-muted-foreground text-lg max-w-2xl mx-auto">
            Simple, transparent process to join India's top engineering
            university
          </p>
        </div>

        {/* Steps */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {steps.map((s, i) => (
            <div
              key={s.step}
              className="fade-in-up relative flex flex-col items-center text-center p-6 rounded-xl bg-secondary"
              style={{ transitionDelay: `${i * 0.1}s` }}
            >
              <div className="absolute -top-4 left-6 font-display text-5xl font-bold text-navy/10">
                {s.step}
              </div>
              <div className="w-14 h-14 bg-navy rounded-full flex items-center justify-center mb-4">
                <s.icon className="w-7 h-7 text-gold" />
              </div>
              <h3 className="font-bold text-navy text-lg mb-2">{s.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {s.desc}
              </p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {/* Eligibility */}
          <div className="fade-in-up lg:col-span-2">
            <h3 className="font-display text-2xl font-bold text-navy mb-6">
              Eligibility Criteria
            </h3>
            <div className="overflow-x-auto rounded-xl border border-border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-navy text-white">
                    <th className="px-4 py-3 text-left font-semibold">
                      Program
                    </th>
                    <th className="px-4 py-3 text-left font-semibold">
                      Qualification
                    </th>
                    <th className="px-4 py-3 text-left font-semibold">
                      Min. Score
                    </th>
                    <th className="px-4 py-3 text-left font-semibold">
                      Entrance
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {eligibility.map((row, i) => (
                    <tr
                      key={row.program}
                      className={i % 2 === 0 ? "bg-white" : "bg-secondary"}
                    >
                      <td className="px-4 py-3 font-bold text-navy">
                        {row.program}
                      </td>
                      <td className="px-4 py-3 text-foreground">
                        {row.qualification}
                      </td>
                      <td className="px-4 py-3 text-foreground">{row.min}</td>
                      <td className="px-4 py-3 text-foreground">
                        {row.entrance}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Important Dates */}
          <div className="fade-in-up" style={{ transitionDelay: "0.2s" }}>
            <h3 className="font-display text-2xl font-bold text-navy mb-6">
              Important Dates
            </h3>
            <div className="space-y-3">
              {dates.map((d) => (
                <div
                  key={d.event}
                  className="flex items-center justify-between p-3 rounded-lg bg-secondary"
                >
                  <span className="text-sm font-medium text-foreground">
                    {d.event}
                  </span>
                  <span className="text-sm font-bold text-gold">{d.date}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Fee Structure */}
        <div className="fade-in-up mb-12">
          <h3 className="font-display text-2xl font-bold text-navy mb-6">
            Fee Structure
          </h3>
          <div className="grid sm:grid-cols-3 gap-6">
            {fees.map((f) => (
              <div
                key={f.program}
                className="rounded-xl border border-border p-6 hover-lift"
              >
                <div className="text-gold font-bold text-2xl font-display mb-1">
                  {f.program}
                </div>
                <div className="text-muted-foreground text-xs uppercase tracking-widest mb-4">
                  Per Annum
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tuition Fee</span>
                    <span className="font-semibold text-foreground">
                      {f.annual}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Hostel Fee</span>
                    <span className="font-semibold text-foreground">
                      {f.hostel}
                    </span>
                  </div>
                  <hr className="border-border" />
                  <div className="flex justify-between">
                    <span className="font-bold text-navy">Total</span>
                    <span className="font-bold text-navy">{f.total}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <button
            type="button"
            onClick={() => setShowModal(true)}
            data-ocid="admissions.primary_button"
            className="bg-gold hover:bg-gold-dark text-navy-dark font-bold py-4 px-12 rounded-md text-lg uppercase tracking-wide transition-all hover:shadow-xl hover:-translate-y-0.5"
          >
            Apply Now for 2026
          </button>
          <p className="text-muted-foreground text-sm mt-3">
            Applications are open. Secure your seat today.
          </p>
        </div>
      </div>
    </section>
  );
}
