import { Calendar, ChevronDown, ChevronUp } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useState } from "react";

const bgImages = [
  "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1600&q=80",
  "https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=1600&q=80",
  "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=1600&q=80",
  "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=1600&q=80",
  "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=1600&q=80",
];

const bgImageIds = ["conf", "grad", "fest", "stage", "concert"];

const events = [
  {
    id: 1,
    name: "AuxeroTech Fest",
    date: "February 2026",
    type: "Technical",
    description:
      "Annual national-level technical festival bringing together the brightest minds from across India.",
    highlights: [
      "24-Hour Hackathon",
      "Robotics War Championship",
      "Paper Presentation",
      "Coding Contest",
    ],
    details:
      "AuxeroTech Fest is Auxeron University's flagship technical event, attracting 5000+ participants from 200+ colleges nationwide. The festival spans 3 action-packed days with 50+ events across software, hardware, robotics, and emerging technologies. Industry leaders from top tech companies serve as judges and mentors. The prize pool of ₹10 Lakhs includes cash prizes, internship offers, and startup incubation opportunities.",
    stats: [
      "5000+ Participants",
      "200+ Colleges",
      "50+ Events",
      "₹10L Prize Pool",
    ],
    photo:
      "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80",
    color: "from-blue-900 to-blue-700",
  },
  {
    id: 2,
    name: "Aurex-Con Cultural Fest",
    date: "March 2026",
    type: "Cultural",
    description:
      "The biggest cultural extravaganza of the academic year — 3 days of music, dance, drama and art.",
    highlights: [
      "Celebrity Performances",
      "Battle of Bands",
      "Classical Dance Showcase",
      "Fashion Show",
    ],
    details:
      "Aurex-Con is where creativity meets passion. This three-day cultural festival celebrates art in all its forms — from classical Bharatanatyam to contemporary hip-hop, from street plays to stand-up comedy. National celebrities headline the main stage each evening. The Street Play competition draws social commentary through powerful performances. Over 2000 students participate in 40+ events across music, dance, drama, art, and literary competitions.",
    stats: ["2000+ Performers", "3 Days", "40+ Events", "Celebrity Headliners"],
    photo:
      "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80",
    color: "from-purple-900 to-purple-700",
  },
  {
    id: 3,
    name: "Annual Sports Meet",
    date: "January 2026",
    type: "Sports",
    description:
      "Inter-department sports championship across 15 disciplines, uniting 1200+ athletes in friendly competition.",
    highlights: [
      "Athletics Track Events",
      "Cricket & Football",
      "Swimming Championship",
      "Kabaddi & Volleyball",
    ],
    details:
      "The Annual Sports Meet is a week-long celebration of athletic excellence, sportsmanship, and team spirit. All 8 departments field their best athletes across 15 sports disciplines. The opening ceremony features a grand march-past by all departments. Medal events run from 6 AM to 8 PM each day. The closing ceremony includes a trophy presentation, the coveted Overall Champions Shield, and recognition of outstanding sportspersons. Professional coaching staff from national-level sports academies supervise the events.",
    stats: ["1200+ Athletes", "15 Sports", "8 Departments", "7 Days"],
    photo:
      "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&q=80",
    color: "from-green-900 to-green-700",
  },
  {
    id: 4,
    name: "Convocation Ceremony",
    date: "April 2026",
    type: "Academic",
    description:
      "Grand graduation ceremony honoring the outgoing batch — a milestone moment celebrating years of hard work.",
    highlights: [
      "Chief Guest Address",
      "Gold Medal Awards",
      "Degree Distribution",
      "Doctoral Hooding",
    ],
    details:
      "The Annual Convocation is the most formal and prestigious event on the university calendar. Graduating students receive their degrees from the Chancellor and an eminent Chief Guest — typically a Cabinet Minister, Supreme Court Judge, or industry titan. Gold medals are awarded to department toppers. Ph.D. scholars receive their doctoral hoods in a solemn academic ceremony. The event is attended by proud families, alumni, faculty, and dignitaries. A grand alumni reunion dinner follows the formal ceremony, connecting generations of Auxeron graduates.",
    stats: [
      "1200+ Graduates",
      "20+ Gold Medals",
      "30+ Doctorates",
      "Distinguished Guests",
    ],
    photo:
      "https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=800&q=80",
    color: "from-amber-900 to-amber-700",
  },
  {
    id: 5,
    name: "48-Hour Hackathon",
    date: "December 2025",
    type: "Technical",
    description:
      "Industry-sponsored 48-hour non-stop problem-solving marathon with real-world challenges.",
    highlights: [
      "₹5L Prize Money",
      "Google & Amazon Mentors",
      "Live Product Demos",
      "On-Spot Internships",
    ],
    details:
      "The Auxeron 48-Hour Hackathon challenges teams of 3-5 to build working solutions to real-world problems posed by industry partners. Problem statements span AI/ML, fintech, healthtech, sustainability, and smart cities. Engineers and product managers from Google, Amazon, Microsoft, and leading startups serve as mentors throughout the event. Top teams demo their products to a panel of VCs and industry leaders. Winners receive cash prizes totaling ₹5 Lakhs, plus internship offers and potential startup funding from partnering incubators.",
    stats: [
      "500+ Participants",
      "₹5L Prizes",
      "15+ Mentors",
      "Internship Offers",
    ],
    photo:
      "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&q=80",
    color: "from-red-900 to-red-700",
  },
  {
    id: 6,
    name: "Distinguished Lecture Series",
    date: "Every Month",
    type: "Academic",
    description:
      "Monthly talks by global leaders, scientists, Nobel laureates and Fortune 500 CEOs.",
    highlights: [
      "Nobel Laureate Talks",
      "Industry Titan Sessions",
      "Cutting-Edge Research",
      "Q&A & Networking",
    ],
    details:
      "The Auxeron Distinguished Lecture Series brings world-class thinkers to our campus every month. Past speakers have included Nobel Prize winners in Physics and Medicine, heads of ISRO, CEOs of Fortune 500 companies, acclaimed scientists from NASA and CERN, and pioneers of the Indian startup ecosystem. Each lecture is followed by an open Q&A session and a networking reception, giving students and faculty direct access to some of the world's most brilliant minds. Certificates of attendance are issued to all registered participants.",
    stats: [
      "12+ Lectures/Year",
      "Nobel Laureates",
      "Open to All",
      "Certificate Given",
    ],
    photo:
      "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&q=80",
    color: "from-teal-900 to-teal-700",
  },
];

const typeBadgeColors: Record<string, string> = {
  Technical: "bg-blue-100 text-blue-800",
  Cultural: "bg-purple-100 text-purple-800",
  Sports: "bg-green-100 text-green-800",
  Academic: "bg-amber-100 text-amber-800",
};

export function EventsSection() {
  const [bgIndex, setBgIndex] = useState(0);
  const [prevIndex, setPrevIndex] = useState<number | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setPrevIndex(bgIndex);
      setBgIndex((i) => (i + 1) % bgImages.length);
    }, 3500);
    return () => clearInterval(timer);
  }, [bgIndex]);

  const toggleExpand = (id: number) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const goToSlide = (idx: number) => {
    setPrevIndex(bgIndex);
    setBgIndex(idx);
  };

  return (
    <section id="events" className="w-full">
      {/* Background Slider Header */}
      <div className="relative h-[480px] overflow-hidden flex items-center justify-center">
        {/* Previous image fading out */}
        {prevIndex !== null && (
          <div
            key={`prev-${bgImageIds[prevIndex]}`}
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${bgImages[prevIndex]})` }}
          />
        )}
        {/* Current image fading in */}
        <AnimatePresence>
          <motion.div
            key={bgImageIds[bgIndex]}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.2, ease: "easeInOut" }}
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${bgImages[bgIndex]})` }}
          />
        </AnimatePresence>

        {/* Dark gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-navy/80 via-navy/60 to-navy/90" />

        {/* Header content */}
        <div className="relative z-10 text-center px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="text-gold text-sm font-bold uppercase tracking-widest mb-3">
              Life Beyond Classrooms
            </div>
            <h2 className="font-display text-5xl sm:text-6xl font-bold text-white mb-4 gold-underline">
              Events at Auxeron
            </h2>
            <p className="text-white/80 text-xl mt-6 max-w-2xl mx-auto">
              Where learning meets celebration
            </p>

            {/* Slider dots */}
            <div className="flex gap-2 justify-center mt-8">
              {bgImageIds.map((imgId, dotIdx) => (
                <button
                  type="button"
                  key={imgId}
                  onClick={() => goToSlide(dotIdx)}
                  data-ocid="events.toggle"
                  className={`rounded-full transition-all duration-300 ${
                    dotIdx === bgIndex
                      ? "w-8 h-2 bg-gold"
                      : "w-2 h-2 bg-white/50 hover:bg-white/80"
                  }`}
                />
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Event Cards */}
      <div className="bg-white py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {events.map((event, i) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 flex flex-col bg-white border border-gray-100"
                data-ocid={`events.item.${i + 1}`}
              >
                {/* Photo */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={event.photo}
                    alt={event.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                  <div
                    className={`absolute inset-0 bg-gradient-to-t ${event.color} opacity-40`}
                  />
                  <span
                    className={`absolute top-3 right-3 text-xs font-bold px-3 py-1 rounded-full ${typeBadgeColors[event.type]}`}
                  >
                    {event.type}
                  </span>
                </div>

                {/* Card Content */}
                <div className="p-6 flex flex-col flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-display text-xl font-bold text-navy leading-tight">
                      {event.name}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2 text-muted-foreground text-xs mb-3">
                    <Calendar className="w-3.5 h-3.5" />
                    <span className="font-semibold">{event.date}</span>
                  </div>

                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    {event.description}
                  </p>

                  {/* Highlights */}
                  <ul className="space-y-1.5 mb-5 flex-1">
                    {event.highlights.map((h) => (
                      <li
                        key={h}
                        className="flex items-center gap-2 text-xs text-navy/80"
                      >
                        <span className="w-1.5 h-1.5 bg-gold rounded-full flex-shrink-0" />
                        {h}
                      </li>
                    ))}
                  </ul>

                  {/* View Details Button */}
                  <button
                    type="button"
                    onClick={() => toggleExpand(event.id)}
                    data-ocid={`events.button.${i + 1}`}
                    className="flex items-center justify-between w-full bg-navy hover:bg-navy-mid text-white text-sm font-bold py-2.5 px-4 rounded-lg transition-colors"
                  >
                    <span>
                      {expandedId === event.id
                        ? "Hide Details"
                        : "View Details"}
                    </span>
                    {expandedId === event.id ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </button>

                  {/* Expanded Details */}
                  <AnimatePresence>
                    {expandedId === event.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.35 }}
                        className="overflow-hidden"
                      >
                        <div className="pt-4 border-t border-gray-100 mt-4">
                          <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                            {event.details}
                          </p>
                          <div className="grid grid-cols-2 gap-2">
                            {event.stats.map((stat) => (
                              <div
                                key={stat}
                                className="bg-secondary rounded-lg px-3 py-2 text-xs font-bold text-navy text-center"
                              >
                                {stat}
                              </div>
                            ))}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
