import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { useEffect, useRef } from "react";
import { useDepartments } from "../hooks/useQueries";

const deptEmojis: Record<string, string> = {
  "Computer Science": "💻",
  CSE: "💻",
  Electronics: "📡",
  ECE: "📡",
  Mechanical: "⚙️",
  Civil: "🏗️",
  Electrical: "⚡",
  EE: "⚡",
  Chemical: "🧪",
  Aerospace: "✈️",
  Biotechnology: "🧬",
  Biotech: "🧬",
  "Information Technology": "🖥️",
  "Artificial Intelligence": "🤖",
  Industrial: "🏭",
};

function getDeptEmoji(name: string) {
  for (const [key, emoji] of Object.entries(deptEmojis)) {
    if (name.includes(key)) return emoji;
  }
  return "🎓";
}

const slugMap: Record<string, string> = {
  "Computer Science & Engineering": "computer-science",
  "Electronics & Communication Engineering": "electronics-communication",
  "Mechanical Engineering": "mechanical-engineering",
  "Civil Engineering": "civil-engineering",
  "Electrical Engineering": "electrical-engineering",
  "Chemical Engineering": "chemical-engineering",
  "Aerospace Engineering": "aerospace-engineering",
  "Biotechnology Engineering": "biotechnology-engineering",
  "Information Technology": "information-technology",
  "Artificial Intelligence & Data Science": "ai-data-science",
  "Industrial & Production Engineering": "industrial-engineering",
};

function getDeptSlug(name: string) {
  return (
    slugMap[name] ||
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")
  );
}

const fallbackDepts = [
  {
    id: 1n,
    name: "Computer Science & Engineering",
    description:
      "Cutting-edge programs in AI, ML, cloud computing, and software engineering.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 45n,
    establishedYear: 1980n,
  },
  {
    id: 2n,
    name: "Electronics & Communication Engineering",
    description:
      "Advanced study in VLSI, signal processing, embedded systems and IoT.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 38n,
    establishedYear: 1978n,
  },
  {
    id: 3n,
    name: "Mechanical Engineering",
    description:
      "Classical and modern mechanical engineering with robotics and automation.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 42n,
    establishedYear: 1974n,
  },
  {
    id: 4n,
    name: "Civil Engineering",
    description:
      "Infrastructure design, structural engineering and sustainable construction.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 35n,
    establishedYear: 1974n,
  },
  {
    id: 5n,
    name: "Electrical Engineering",
    description:
      "Power systems, renewable energy, smart grids and electric vehicles.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 32n,
    establishedYear: 1976n,
  },
  {
    id: 6n,
    name: "Chemical Engineering",
    description:
      "Process engineering, polymer technology and petroleum refining.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 28n,
    establishedYear: 1982n,
  },
  {
    id: 7n,
    name: "Aerospace Engineering",
    description:
      "Aerodynamics, propulsion, spacecraft design and avionics systems.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 25n,
    establishedYear: 1990n,
  },
  {
    id: 8n,
    name: "Biotechnology Engineering",
    description:
      "Bioprocess engineering, genomics, bioinformatics and pharmaceutical technology.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 22n,
    establishedYear: 1995n,
  },
  {
    id: 9n,
    name: "Information Technology",
    description:
      "Enterprise software, networking, cloud computing, and web technologies.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 35n,
    establishedYear: 1998n,
  },
  {
    id: 10n,
    name: "Artificial Intelligence & Data Science",
    description:
      "Deep learning, NLP, computer vision and intelligent systems engineering.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 28n,
    establishedYear: 2018n,
  },
  {
    id: 11n,
    name: "Industrial & Production Engineering",
    description:
      "Lean manufacturing, supply chain management, quality engineering and Industry 4.0.",
    programs: ["B.Tech", "M.Tech", "Ph.D"],
    facultyCount: 20n,
    establishedYear: 2005n,
  },
];

const seatsMap: Record<string, number> = {
  "Computer Science": 180,
  Electronics: 120,
  Mechanical: 150,
  Civil: 120,
  Electrical: 90,
  Chemical: 60,
  Aerospace: 60,
  Biotechnology: 60,
  "Information Technology": 120,
  "Artificial Intelligence": 90,
  Industrial: 60,
};

function getSeats(name: string) {
  for (const [key, seats] of Object.entries(seatsMap)) {
    if (name.includes(key)) return seats;
  }
  return 60;
}

export function AcademicsSection() {
  const { data: departments } = useDepartments();
  const depts =
    departments && departments.length > 0 ? departments : fallbackDepts;
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        }
      },
      { threshold: 0.05 },
    );
    const els = ref.current?.querySelectorAll(".fade-in-up");
    if (els) {
      for (const el of els) observer.observe(el);
    }
    return () => observer.disconnect();
  }, []);

  const ugDepts = depts.filter((d) => d.programs.includes("B.Tech"));
  const pgDepts = depts.filter((d) => d.programs.includes("M.Tech"));
  const phdDepts = depts.filter((d) => d.programs.includes("Ph.D"));

  return (
    <section id="academics" className="py-20 bg-secondary" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
            Academics
          </h2>
          <p className="mt-8 text-muted-foreground text-lg max-w-2xl mx-auto">
            11 departments, 30+ programs, world-class faculty
          </p>
        </div>

        <Tabs defaultValue="ug" data-ocid="academics.tab">
          <TabsList className="mx-auto flex w-fit mb-10 bg-navy/10">
            <TabsTrigger
              value="ug"
              className="data-[state=active]:bg-navy data-[state=active]:text-white font-semibold uppercase tracking-wide"
            >
              Undergraduate
            </TabsTrigger>
            <TabsTrigger
              value="pg"
              className="data-[state=active]:bg-navy data-[state=active]:text-white font-semibold uppercase tracking-wide"
            >
              Postgraduate
            </TabsTrigger>
            <TabsTrigger
              value="phd"
              className="data-[state=active]:bg-navy data-[state=active]:text-white font-semibold uppercase tracking-wide"
            >
              Doctoral
            </TabsTrigger>
          </TabsList>

          {[
            {
              value: "ug",
              list: ugDepts,
              program: "B.Tech",
              duration: "4 Years",
            },
            {
              value: "pg",
              list: pgDepts,
              program: "M.Tech",
              duration: "2 Years",
            },
            {
              value: "phd",
              list: phdDepts,
              program: "Ph.D",
              duration: "3–5 Years",
            },
          ].map(({ value, list, duration }) => (
            <TabsContent key={value} value={value}>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {list.map((dept, i) => (
                  <div
                    key={String(dept.id)}
                    className="fade-in-up bg-white rounded-xl p-6 shadow-card hover-lift flex flex-col"
                    style={{ transitionDelay: `${i * 0.05}s` }}
                    data-ocid={`academics.item.${i + 1}`}
                  >
                    <div className="text-4xl mb-4">
                      {getDeptEmoji(dept.name)}
                    </div>
                    <h3 className="font-bold text-navy text-base leading-snug mb-2">
                      {dept.name}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mb-4 flex-1">
                      {dept.description}
                    </p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                      <span className="bg-secondary px-2 py-1 rounded font-semibold">
                        {duration}
                      </span>
                      <span>{getSeats(dept.name)} seats</span>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        navigate({
                          to: "/department/$dept",
                          params: { dept: getDeptSlug(dept.name) },
                        })
                      }
                      data-ocid={`academics.button.${i + 1}`}
                      className="w-full flex items-center justify-center gap-2 border-2 border-navy text-navy hover:bg-navy hover:text-white font-semibold py-2 rounded-md text-sm transition-all"
                    >
                      View Details <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
}
