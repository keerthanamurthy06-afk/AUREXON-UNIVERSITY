import { useEffect, useRef } from "react";
import { useStatistics } from "../hooks/useQueries";

const fallbackStats = [
  { value: "15,000+", label: "Students" },
  { value: "850+", label: "Faculty Members" },
  { value: "50+", label: "Years of Excellence" },
  { value: "98%", label: "Placement Rate" },
];

export function StatsBar() {
  const { data: stats } = useStatistics();
  const ref = useRef<HTMLDivElement>(null);

  const displayStats = stats
    ? [
        {
          value: `${Number(stats.totalStudents).toLocaleString()}+`,
          label: "Students",
        },
        { value: `${Number(stats.facultyCount)}+`, label: "Faculty Members" },
        {
          value: `${Number(stats.yearsEstablished)}+`,
          label: "Years of Excellence",
        },
        {
          value: `${Math.round(stats.placementPercentage)}%`,
          label: "Placement Rate",
        },
      ]
    : fallbackStats;

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        }
      },
      { threshold: 0.3 },
    );
    const els = ref.current?.querySelectorAll(".fade-in-up");
    if (els) {
      for (const el of els) {
        observer.observe(el);
      }
    }
    return () => observer.disconnect();
  }, []);

  return (
    <section id="stats" className="bg-navy-dark py-10" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-0 lg:divide-x divide-white/20">
          {displayStats.map((stat, i) => (
            <div
              key={stat.label}
              className="fade-in-up text-center lg:px-8 py-2"
              style={{ transitionDelay: `${i * 0.1}s` }}
            >
              <div className="font-display text-4xl lg:text-5xl font-bold text-gold mb-1">
                {stat.value}
              </div>
              <div className="text-white/70 text-sm font-semibold uppercase tracking-widest">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
