import { Mail } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { Faculty } from "../backend.d";
import { useFaculties } from "../hooks/useQueries";

const fallbackFaculty: Faculty[] = [
  {
    id: 1n,
    name: "Dr. Rajesh Kumar",
    designation: "Professor & Head",
    department: "Computer Science & Engineering",
    specialization: "Artificial Intelligence & Machine Learning",
    email: "r.kumar@aurexon.edu",
    publications: 87n,
  },
  {
    id: 2n,
    name: "Dr. Priya Sharma",
    designation: "Associate Professor",
    department: "Electronics & Communication Engineering",
    specialization: "VLSI Design & Embedded Systems",
    email: "p.sharma@aurexon.edu",
    publications: 54n,
  },
  {
    id: 3n,
    name: "Dr. Amit Singh",
    designation: "Professor",
    department: "Mechanical Engineering",
    specialization: "Robotics & Manufacturing Automation",
    email: "a.singh@aurexon.edu",
    publications: 72n,
  },
  {
    id: 4n,
    name: "Dr. Sunita Patel",
    designation: "Professor & Head",
    department: "Civil Engineering",
    specialization: "Structural Engineering & Smart Concrete",
    email: "s.patel@aurexon.edu",
    publications: 63n,
  },
  {
    id: 5n,
    name: "Dr. Vikram Rao",
    designation: "Associate Professor",
    department: "Electrical Engineering",
    specialization: "Power Systems & Renewable Energy",
    email: "v.rao@aurexon.edu",
    publications: 48n,
  },
  {
    id: 6n,
    name: "Dr. Meera Iyer",
    designation: "Professor",
    department: "Biotechnology Engineering",
    specialization: "Genomics & Bioinformatics",
    email: "m.iyer@aurexon.edu",
    publications: 91n,
  },
];

function getInitials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0])
    .join("")
    .toUpperCase();
}

const avatarColors = [
  "bg-blue-600",
  "bg-purple-600",
  "bg-emerald-600",
  "bg-rose-600",
  "bg-amber-600",
  "bg-teal-600",
];

export function FacultySection() {
  const { data: facultyData } = useFaculties();
  const allFaculty =
    facultyData && facultyData.length > 0 ? facultyData : fallbackFaculty;
  const departments = [
    "All",
    ...Array.from(new Set(allFaculty.map((f) => f.department))),
  ];
  const [activeTab, setActiveTab] = useState("All");
  const ref = useRef<HTMLDivElement>(null);

  const filtered =
    activeTab === "All"
      ? allFaculty
      : allFaculty.filter((f) => f.department === activeTab);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        }
      },
      { threshold: 0.05 },
    );
    const els = ref.current?.querySelectorAll(".fade-in-up");
    if (els) {
      for (const el of els) {
        observer.observe(el);
      }
    }
    return () => observer.disconnect();
  }, []);

  return (
    <section id="faculty" className="py-20 bg-secondary" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
            Our Faculty
          </h2>
          <p className="mt-8 text-muted-foreground text-lg max-w-2xl mx-auto">
            850+ distinguished faculty shaping the engineers of tomorrow
          </p>
        </div>

        {/* Dept filter tabs */}
        <div className="flex flex-wrap gap-2 mb-10 justify-center">
          {departments.slice(0, 6).map((dept) => (
            <button
              type="button"
              key={dept}
              onClick={() => setActiveTab(dept)}
              data-ocid="faculty.tab"
              className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
                activeTab === dept
                  ? "bg-navy text-white"
                  : "bg-white text-navy border border-border hover:border-navy"
              }`}
            >
              {dept === "All"
                ? "All Departments"
                : dept.split(" ").slice(0, 2).join(" ")}
            </button>
          ))}
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.slice(0, 6).map((faculty, i) => (
            <div
              key={String(faculty.id)}
              className="fade-in-up bg-white rounded-xl p-6 shadow-card hover-lift"
              style={{ transitionDelay: `${i * 0.08}s` }}
              data-ocid={`faculty.item.${i + 1}`}
            >
              <div className="flex items-start gap-4 mb-4">
                <div
                  className={`w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-lg flex-shrink-0 ${avatarColors[i % avatarColors.length]}`}
                >
                  {getInitials(faculty.name)}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-navy text-base leading-snug">
                    {faculty.name}
                  </h3>
                  <p className="text-gold text-sm font-semibold">
                    {faculty.designation}
                  </p>
                  <p className="text-muted-foreground text-xs mt-0.5 truncate">
                    {faculty.department}
                  </p>
                </div>
              </div>
              <div className="bg-secondary rounded-lg p-3 mb-4">
                <p className="text-sm text-foreground font-medium">
                  {faculty.specialization}
                </p>
              </div>
              <div className="flex items-center justify-between">
                <a
                  href={`mailto:${faculty.email}`}
                  data-ocid={`faculty.link.${i + 1}`}
                  className="flex items-center gap-2 text-navy hover:text-gold text-sm transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  <span className="truncate max-w-[160px]">
                    {faculty.email}
                  </span>
                </a>
                <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded font-semibold">
                  {String(faculty.publications)} pubs
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
