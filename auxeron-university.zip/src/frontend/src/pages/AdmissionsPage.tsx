import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle, Send } from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AdmissionsSection } from "../components/AdmissionsSection";
import { Footer } from "../components/Footer";
import { Header } from "../components/Header";

const programs = ["B.Tech", "M.Tech", "Ph.D"];
const departments = [
  "Computer Science & Engineering",
  "Electronics & Communication Engineering",
  "Mechanical Engineering",
  "Civil Engineering",
  "Electrical Engineering",
  "Chemical Engineering",
  "Aerospace Engineering",
  "Biotechnology Engineering",
];

export function AdmissionsPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    program: "",
    department: "",
    sop: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(
      `Application: ${formData.program} - ${formData.name}`,
    );
    const dateStr = new Date().toLocaleDateString("en-IN", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
    const bodyText = `AUREXON UNIVERSITY - APPLICATION FORM\n=====================================\n\nFull Name: ${formData.name}\nEmail Address: ${formData.email}\nPhone Number: ${formData.phone}\nProgram Applied: ${formData.program}\nDepartment: ${formData.department}\n\nStatement of Purpose:\n${formData.sop}\n\nSubmitted on: ${dateStr}`;
    const body = encodeURIComponent(bodyText);
    window.location.href = `mailto:admissions@aurexon.edu?subject=${subject}&body=${body}`;
    setSubmitted(true);
    toast.success(
      "Application email opened! Please send the email to complete your application.",
    );
  };

  return (
    <div className="min-h-screen font-body">
      <Header />
      <main>
        {/* Page Banner */}
        <section
          className="pt-32 pb-16 relative overflow-hidden"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.18 0.055 248) 0%, oklch(0.25 0.065 248) 100%)",
          }}
        >
          <div className="absolute inset-0 blueprint-bg opacity-30" />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-gold text-sm font-bold uppercase tracking-widest mb-3">
                Join Us
              </div>
              <h1 className="font-display text-5xl font-bold text-white mb-4">
                Admissions 2026
              </h1>
              <p className="text-white/70 text-lg max-w-2xl">
                Begin your engineering journey at Aurexon. Applications for the
                2026 batch are now open.
              </p>
            </motion.div>
          </div>
        </section>

        <AdmissionsSection />

        {/* Application Form */}
        <section className="py-20 bg-secondary" id="apply-form">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-center mb-12">
                <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
                  Apply Online
                </h2>
                <p className="mt-8 text-muted-foreground text-lg">
                  Fill in your details below. Clicking Submit will open your
                  email client (Gmail, Outlook, etc.) pre-filled with your
                  application — just hit send!
                </p>
              </div>

              {submitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-white rounded-2xl p-12 text-center shadow-card"
                  data-ocid="admissions.success_state"
                >
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="w-10 h-10 text-green-600" />
                  </div>
                  <h3 className="font-display text-2xl font-bold text-navy mb-3">
                    Email Client Opened!
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    Your application email should be open in your email client
                    (Gmail, Outlook, etc.). Please review and click{" "}
                    <strong>Send</strong> to submit your application to
                    admissions@aurexon.edu
                  </p>
                  <button
                    type="button"
                    onClick={() => setSubmitted(false)}
                    className="text-navy font-semibold hover:text-gold transition-colors underline"
                  >
                    Submit Another Application
                  </button>
                </motion.div>
              ) : (
                <form
                  onSubmit={handleSubmit}
                  className="bg-white rounded-2xl p-8 shadow-card space-y-6"
                  data-ocid="admissions.modal"
                >
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label
                        htmlFor="app-name"
                        className="text-sm font-bold text-navy"
                      >
                        Full Name *
                      </Label>
                      <Input
                        id="app-name"
                        required
                        data-ocid="admissions.input"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData((p) => ({ ...p, name: e.target.value }))
                        }
                        placeholder="e.g. Rahul Sharma"
                        className="border-border"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label
                        htmlFor="app-email"
                        className="text-sm font-bold text-navy"
                      >
                        Email Address *
                      </Label>
                      <Input
                        id="app-email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) =>
                          setFormData((p) => ({ ...p, email: e.target.value }))
                        }
                        placeholder="your@gmail.com"
                        className="border-border"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label
                        htmlFor="app-phone"
                        className="text-sm font-bold text-navy"
                      >
                        Phone Number *
                      </Label>
                      <Input
                        id="app-phone"
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData((p) => ({ ...p, phone: e.target.value }))
                        }
                        placeholder="+91 XXXXX XXXXX"
                        className="border-border"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-bold text-navy">
                        Select Program *
                      </Label>
                      <Select
                        required
                        value={formData.program}
                        onValueChange={(v) =>
                          setFormData((p) => ({ ...p, program: v }))
                        }
                      >
                        <SelectTrigger
                          data-ocid="admissions.select"
                          className="border-border"
                        >
                          <SelectValue placeholder="B.Tech / M.Tech / Ph.D" />
                        </SelectTrigger>
                        <SelectContent>
                          {programs.map((prog) => (
                            <SelectItem key={prog} value={prog}>
                              {prog}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-bold text-navy">
                      Select Department *
                    </Label>
                    <Select
                      required
                      value={formData.department}
                      onValueChange={(v) =>
                        setFormData((p) => ({ ...p, department: v }))
                      }
                    >
                      <SelectTrigger
                        data-ocid="admissions.select"
                        className="border-border"
                      >
                        <SelectValue placeholder="Choose your department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((dept) => (
                          <SelectItem key={dept} value={dept}>
                            {dept}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label
                      htmlFor="app-sop"
                      className="text-sm font-bold text-navy"
                    >
                      Statement of Purpose / Message *
                    </Label>
                    <Textarea
                      id="app-sop"
                      required
                      data-ocid="admissions.textarea"
                      value={formData.sop}
                      onChange={(e) =>
                        setFormData((p) => ({ ...p, sop: e.target.value }))
                      }
                      placeholder="Tell us about yourself, your academic background, and why you want to join Aurexon University..."
                      rows={5}
                      className="border-border resize-none"
                    />
                  </div>

                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
                    <strong>How it works:</strong> Clicking Submit Application
                    will open your email client (Gmail, Outlook, etc.) with all
                    your details pre-filled. Simply click <strong>Send</strong>{" "}
                    in your email app to complete the application.
                  </div>

                  <button
                    type="submit"
                    data-ocid="admissions.submit_button"
                    className="w-full flex items-center justify-center gap-3 bg-gold hover:bg-gold-dark text-navy-dark font-bold py-4 px-8 rounded-xl text-base uppercase tracking-wide transition-all hover:shadow-xl hover:-translate-y-0.5"
                  >
                    <Send className="w-5 h-5" />
                    Submit Application
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
