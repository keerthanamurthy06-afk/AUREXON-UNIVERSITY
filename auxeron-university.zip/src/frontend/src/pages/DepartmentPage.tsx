import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate, useParams } from "@tanstack/react-router";
import {
  ArrowLeft,
  Award,
  BookOpen,
  Briefcase,
  Building,
  Calendar,
  DollarSign,
  GraduationCap,
  Star,
  Users,
} from "lucide-react";
import { Footer } from "../components/Footer";
import { Header } from "../components/Header";

interface Department {
  slug: string;
  name: string;
  emoji: string;
  tagline: string;
  overview: string;
  seats: number;
  faculty: number;
  established: number;
  fee: string;
  avgPlacement: string;
  topCompanies: string[];
  eligibility: string;
  curriculum: { sem: string; subjects: string[] }[];
  specializations: { name: string; desc: string }[];
  careers: { role: string; avg: string }[];
  admissionSteps: string[];
}

const departments: Department[] = [
  {
    slug: "computer-science",
    name: "Computer Science & Engineering",
    emoji: "💻",
    tagline: "AI, ML, Cloud & Software Engineering",
    overview:
      "The Department of Computer Science & Engineering at Aurexon University is one of the most prestigious programs in India. We offer cutting-edge programs in Artificial Intelligence, Machine Learning, Cloud Computing, Cybersecurity, and Software Engineering. Our graduates are among the highest-placed engineers in the country, working at Google, Microsoft, Amazon, and leading startups worldwide.",
    seats: 180,
    faculty: 45,
    established: 1980,
    fee: "₹1,85,000",
    avgPlacement: "18 LPA",
    topCompanies: ["Google", "Microsoft", "Amazon", "Meta", "Adobe"],
    eligibility: "10+2 with PCM 75%+, JEE Main score required",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Mathematics I",
          "Programming Fundamentals (C)",
          "Digital Logic Design",
          "Engineering Physics",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Engineering Mathematics II",
          "Object Oriented Programming (Java)",
          "Computer Organization",
          "Discrete Mathematics",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Data Structures & Algorithms",
          "Database Management Systems",
          "Computer Networks",
          "Software Engineering",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Operating Systems",
          "Theory of Computation",
          "Design & Analysis of Algorithms",
          "Web Technologies",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "Artificial Intelligence",
          "Machine Learning",
          "Compiler Design",
          "Information Security",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "Deep Learning",
          "Cloud Computing (AWS/GCP)",
          "Big Data Analytics",
          "Mobile Application Development",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (Cybersecurity/IoT/AR-VR)",
          "Elective II (Blockchain/NLP)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III",
          "Professional Ethics",
          "Entrepreneurship",
        ],
      },
    ],
    specializations: [
      {
        name: "AI & Machine Learning",
        desc: "Deep learning, NLP, computer vision, reinforcement learning, and applied AI research.",
      },
      {
        name: "Cloud Computing",
        desc: "AWS, GCP, Azure architectures, DevOps, serverless, and distributed systems.",
      },
      {
        name: "Cybersecurity",
        desc: "Network security, ethical hacking, cryptography, and security operations.",
      },
      {
        name: "Data Science",
        desc: "Statistical analysis, data engineering, visualization, and business intelligence.",
      },
    ],
    careers: [
      { role: "Software Engineer", avg: "20 LPA" },
      { role: "Data Scientist", avg: "22 LPA" },
      { role: "AI/ML Engineer", avg: "25 LPA" },
      { role: "System Architect", avg: "30 LPA" },
      { role: "Cloud Engineer", avg: "18 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main with valid score",
      "Apply online via Aurexon Admissions Portal",
      "Submit 10+2 marksheet (minimum 75% PCM)",
      "Attend counselling and document verification",
      "Pay fee and confirm seat",
    ],
  },
  {
    slug: "electronics-communication",
    name: "Electronics & Communication Engineering",
    emoji: "📡",
    tagline: "VLSI, Embedded Systems, IoT & 5G",
    overview:
      "The ECE department is a hub of innovation in VLSI design, signal processing, embedded systems, IoT, and 5G communications. With state-of-the-art labs including VLSI Fab Lab, RF & Microwave Lab, and Embedded Systems Lab, students gain both theoretical depth and hands-on industry readiness. Our alumni work at Qualcomm, Intel, Texas Instruments, and Samsung R&D.",
    seats: 120,
    faculty: 38,
    established: 1978,
    fee: "₹1,75,000",
    avgPlacement: "14 LPA",
    topCompanies: [
      "Qualcomm",
      "Intel",
      "Texas Instruments",
      "Samsung",
      "Broadcom",
    ],
    eligibility: "10+2 with PCM 75%+, JEE Main score required",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Mathematics I",
          "Basic Electrical Engineering",
          "Engineering Physics",
          "C Programming",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Circuit Theory",
          "Electronic Devices & Circuits",
          "Engineering Mathematics II",
          "Digital Electronics",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Signals & Systems",
          "Analog Circuits",
          "Data Structures",
          "Electromagnetic Theory",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Digital Signal Processing",
          "Microprocessors & Microcontrollers",
          "Communication Engineering",
          "Control Systems",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "VLSI Design",
          "Wireless Communication",
          "Embedded Systems",
          "Antenna & Wave Propagation",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "IoT & Sensor Networks",
          "5G & Next-Gen Wireless",
          "RF Design",
          "FPGA Programming",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (AI for ECE/Radar)",
          "Elective II (Satellite Comm)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III",
          "Technical Communication",
          "Startup Essentials",
        ],
      },
    ],
    specializations: [
      {
        name: "VLSI Design",
        desc: "IC design, chip fabrication, EDA tools, physical design, and verification.",
      },
      {
        name: "Embedded Systems",
        desc: "Microcontrollers, RTOS, firmware development, and hardware-software integration.",
      },
      {
        name: "IoT & 5G",
        desc: "Connected devices, edge computing, 5G protocols, network slicing, and smart cities.",
      },
      {
        name: "Signal Processing",
        desc: "DSP algorithms, image processing, audio engineering, and speech recognition.",
      },
    ],
    careers: [
      { role: "VLSI Engineer", avg: "16 LPA" },
      { role: "Embedded Developer", avg: "13 LPA" },
      { role: "RF Engineer", avg: "15 LPA" },
      { role: "IoT Developer", avg: "12 LPA" },
      { role: "R&D Scientist", avg: "18 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main with valid score",
      "Apply online via Aurexon Admissions Portal",
      "Submit 10+2 marksheet (minimum 75% PCM)",
      "Attend counselling and document verification",
      "Pay fee and confirm seat",
    ],
  },
  {
    slug: "mechanical-engineering",
    name: "Mechanical Engineering",
    emoji: "⚙️",
    tagline: "Robotics, CAD/CAM, Automotive & Thermal",
    overview:
      "Aurexon's Mechanical Engineering department blends classical engineering principles with modern technologies like robotics, automation, and advanced manufacturing. Our students get hands-on experience in CAD/CAM labs, robotics workshops, and thermal engineering facilities. Top recruiters include L&T, Bosch, TATA Motors, and Mahindra.",
    seats: 150,
    faculty: 42,
    established: 1974,
    fee: "₹1,65,000",
    avgPlacement: "11 LPA",
    topCompanies: ["L&T", "Bosch", "TATA Motors", "Mahindra", "Bajaj Auto"],
    eligibility: "10+2 with PCM 75%+, JEE Main score required",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Mathematics I",
          "Engineering Graphics",
          "Basic Mechanics",
          "Chemistry",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Engineering Mathematics II",
          "Thermodynamics I",
          "Materials Science",
          "Manufacturing Processes I",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Engineering Mechanics",
          "Fluid Mechanics",
          "Thermodynamics II",
          "Strength of Materials",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Machine Design I",
          "Kinematics & Dynamics",
          "Heat & Mass Transfer",
          "Manufacturing Processes II",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "Machine Design II",
          "CAD/CAM",
          "Industrial Engineering",
          "Refrigeration & A/C",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "Robotics & Automation",
          "Automobile Engineering",
          "Finite Element Analysis",
          "Operations Research",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (EV Tech/3D Printing)",
          "Elective II (Composite Materials)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III",
          "Professional Ethics",
          "Entrepreneurship",
        ],
      },
    ],
    specializations: [
      {
        name: "Robotics & Automation",
        desc: "Industrial robots, cobots, automation systems, PLC programming, and Industry 4.0.",
      },
      {
        name: "Thermal Engineering",
        desc: "Power plants, HVAC, combustion, turbo machinery, and energy systems.",
      },
      {
        name: "Automotive Engineering",
        desc: "Vehicle dynamics, EV technology, chassis design, and automotive systems.",
      },
      {
        name: "Advanced Manufacturing",
        desc: "CNC machining, additive manufacturing, quality control, and lean production.",
      },
    ],
    careers: [
      { role: "Design Engineer", avg: "10 LPA" },
      { role: "Manufacturing Engineer", avg: "9 LPA" },
      { role: "Robotics Engineer", avg: "14 LPA" },
      { role: "Automotive Engineer", avg: "11 LPA" },
      { role: "R&D Engineer", avg: "13 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main with valid score",
      "Apply online via Aurexon Admissions Portal",
      "Submit 10+2 marksheet (minimum 75% PCM)",
      "Attend counselling and document verification",
      "Pay fee and confirm seat",
    ],
  },
  {
    slug: "civil-engineering",
    name: "Civil Engineering",
    emoji: "🏗️",
    tagline: "Structural, Environmental & Smart Cities",
    overview:
      "The Civil Engineering department at Aurexon focuses on designing resilient infrastructure, sustainable construction, and smart urban systems. With dedicated labs in geotechnical engineering, structural testing, and environmental science, our graduates contribute to nation-building at NHAI, L&T Construction, and PWD. We are pioneers in smart city technology and green building certification.",
    seats: 120,
    faculty: 35,
    established: 1974,
    fee: "₹1,60,000",
    avgPlacement: "10 LPA",
    topCompanies: [
      "L&T Construction",
      "NHAI",
      "PWD",
      "Shapoorji Pallonji",
      "AECOM",
    ],
    eligibility: "10+2 with PCM 75%+, JEE Main score required",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Mathematics I",
          "Engineering Drawing",
          "Building Materials",
          "Surveying I",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Engineering Mathematics II",
          "Fluid Mechanics I",
          "Surveying II",
          "Construction Technology",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Structural Analysis I",
          "Geotechnical Engineering I",
          "Fluid Mechanics II",
          "Concrete Technology",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Structural Analysis II",
          "Geotechnical Engineering II",
          "Transportation Engineering I",
          "Environmental Engineering I",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "Design of RC Structures",
          "Transportation Engineering II",
          "Environmental Engineering II",
          "Hydrology & Water Resources",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "Design of Steel Structures",
          "Construction Management",
          "Smart Cities Technology",
          "GIS & Remote Sensing",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (Bridge Design/Tunnelling)",
          "Elective II (Green Buildings)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III",
          "Project Management",
          "Professional Ethics",
        ],
      },
    ],
    specializations: [
      {
        name: "Structural Engineering",
        desc: "High-rise buildings, bridges, earthquake-resistant design, and FEM analysis.",
      },
      {
        name: "Environmental Engineering",
        desc: "Water treatment, waste management, air quality, and sustainable development.",
      },
      {
        name: "Transportation Engineering",
        desc: "Highway design, traffic management, railways, and urban mobility planning.",
      },
      {
        name: "Smart Cities",
        desc: "GIS, IoT in infrastructure, smart water systems, and digital urban planning.",
      },
    ],
    careers: [
      { role: "Structural Engineer", avg: "9 LPA" },
      { role: "Urban Planner", avg: "10 LPA" },
      { role: "Project Manager", avg: "13 LPA" },
      { role: "Environmental Consultant", avg: "11 LPA" },
      { role: "Site Engineer", avg: "8 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main with valid score",
      "Apply online via Aurexon Admissions Portal",
      "Submit 10+2 marksheet (minimum 75% PCM)",
      "Attend counselling and document verification",
      "Pay fee and confirm seat",
    ],
  },
  {
    slug: "electrical-engineering",
    name: "Electrical Engineering",
    emoji: "⚡",
    tagline: "Power Systems, Renewable Energy & EV Tech",
    overview:
      "Aurexon's Electrical Engineering department is at the forefront of India's energy transition. We specialize in power systems, renewable energy integration, smart grid technology, and electric vehicle engineering. Our students work on real-world projects with NTPC, BHEL, Siemens, and Tesla's India division. The department runs a solar micro-grid and EV testing laboratory.",
    seats: 90,
    faculty: 32,
    established: 1976,
    fee: "₹1,70,000",
    avgPlacement: "12 LPA",
    topCompanies: ["Siemens", "ABB", "NTPC", "BHEL", "Tesla India"],
    eligibility: "10+2 with PCM 75%+, JEE Main score required",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Mathematics I",
          "Basic Electrical Engineering",
          "Engineering Physics",
          "Workshop Practice",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Circuit Analysis",
          "Engineering Mathematics II",
          "Electronic Devices",
          "Digital Electronics",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Electrical Machines I",
          "Network Analysis",
          "Signals & Systems",
          "Measurement & Instrumentation",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Electrical Machines II",
          "Power Systems I",
          "Control Systems",
          "Microprocessors",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "Power Electronics",
          "Power Systems II",
          "High Voltage Engineering",
          "Industrial Drives",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "Renewable Energy Systems",
          "Smart Grid Technology",
          "SCADA & Automation",
          "Electric Vehicles",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (FACTS/Flexible AC)",
          "Elective II (Energy Storage)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III",
          "Power System Reliability",
          "Professional Ethics",
        ],
      },
    ],
    specializations: [
      {
        name: "Power Systems",
        desc: "Generation, transmission, distribution, protection, and power system stability.",
      },
      {
        name: "Renewable Energy",
        desc: "Solar, wind, hydro, biomass energy systems, and grid integration.",
      },
      {
        name: "Control & Automation",
        desc: "PLC, SCADA, industrial automation, robotics drives, and process control.",
      },
      {
        name: "Electric Vehicles",
        desc: "EV powertrain, battery management systems, charging infrastructure, and motor control.",
      },
    ],
    careers: [
      { role: "Power Engineer", avg: "11 LPA" },
      { role: "EV Engineer", avg: "14 LPA" },
      { role: "Control Systems Engineer", avg: "13 LPA" },
      { role: "Energy Consultant", avg: "12 LPA" },
      { role: "Automation Engineer", avg: "12 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main with valid score",
      "Apply online via Aurexon Admissions Portal",
      "Submit 10+2 marksheet (minimum 75% PCM)",
      "Attend counselling and document verification",
      "Pay fee and confirm seat",
    ],
  },
  {
    slug: "chemical-engineering",
    name: "Chemical Engineering",
    emoji: "🧪",
    tagline: "Process Engineering, Polymers & Petroleum",
    overview:
      "Chemical Engineering at Aurexon integrates principles of chemistry, physics, and mathematics to design industrial processes. With dedicated labs in polymer synthesis, reaction engineering, and process simulation, our graduates join ONGC, HPCL, Reliance Industries, and BASF. The department has strong ties with the pharmaceutical and petrochemical industries.",
    seats: 60,
    faculty: 28,
    established: 1982,
    fee: "₹1,60,000",
    avgPlacement: "10 LPA",
    topCompanies: ["ONGC", "HPCL", "Reliance", "BASF", "Haldia Petrochem"],
    eligibility: "10+2 with PCM 75%+, JEE Main score required",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Mathematics I",
          "Engineering Chemistry",
          "Basic Electrical Engineering",
          "C Programming",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Engineering Mathematics II",
          "Chemical Process Calculations",
          "Physical Chemistry",
          "Engineering Physics",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Fluid Mechanics",
          "Thermodynamics",
          "Heat Transfer",
          "Process Instrumentation",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Mass Transfer I",
          "Chemical Reaction Engineering I",
          "Organic Chemistry",
          "Process Control",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "Mass Transfer II",
          "Chemical Reaction Engineering II",
          "Polymer Technology",
          "Catalysis",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "Process Design & Optimization",
          "Petroleum Refining",
          "Safety Engineering",
          "Environmental Engineering",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (Pharmaceutical Engg)",
          "Elective II (Nano Technology)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III",
          "Plant Management",
          "Professional Ethics",
        ],
      },
    ],
    specializations: [
      {
        name: "Process Engineering",
        desc: "Process design, simulation (Aspen), optimization, and scale-up of chemical plants.",
      },
      {
        name: "Polymer Technology",
        desc: "Polymer synthesis, characterization, rubber technology, and plastic processing.",
      },
      {
        name: "Petroleum & Petrochemicals",
        desc: "Crude oil refining, distillation, cracking, natural gas processing, and petrochemical plants.",
      },
      {
        name: "Pharmaceutical Engineering",
        desc: "Drug manufacturing processes, GMP compliance, formulation, and quality control.",
      },
    ],
    careers: [
      { role: "Process Engineer", avg: "10 LPA" },
      { role: "R&D Chemist", avg: "11 LPA" },
      { role: "Safety Engineer", avg: "9 LPA" },
      { role: "Plant Manager", avg: "15 LPA" },
      { role: "Quality Assurance", avg: "9 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main with valid score",
      "Apply online via Aurexon Admissions Portal",
      "Submit 10+2 marksheet (minimum 75% PCM)",
      "Attend counselling and document verification",
      "Pay fee and confirm seat",
    ],
  },
  {
    slug: "aerospace-engineering",
    name: "Aerospace Engineering",
    emoji: "✈️",
    tagline: "Aerodynamics, Propulsion, Spacecraft & UAVs",
    overview:
      "Aurexon's Aerospace Engineering department is one of the few in South India offering specializations in spacecraft design, propulsion systems, and UAV technology. Our state-of-the-art subsonic wind tunnel, avionics lab, and drone testing facility give students unparalleled practical experience. Graduates join ISRO, DRDO, HAL, Boeing, and Airbus, shaping India's aerospace future.",
    seats: 60,
    faculty: 25,
    established: 1990,
    fee: "₹1,90,000",
    avgPlacement: "13 LPA",
    topCompanies: ["ISRO", "DRDO", "HAL", "Boeing India", "Airbus"],
    eligibility: "10+2 with PCM 80%+, JEE Main/Advanced score required",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Mathematics I",
          "Engineering Mechanics",
          "Thermodynamics",
          "C Programming",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Engineering Mathematics II",
          "Fluid Mechanics",
          "Introduction to Aerospace",
          "Engineering Drawing",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Aerodynamics I",
          "Structures I (Aircraft)",
          "Propulsion I",
          "Flight Mechanics",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Aerodynamics II",
          "Structures II (Composite)",
          "Propulsion II (Jet Engines)",
          "Aircraft Performance",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "VLSI for Avionics",
          "Spacecraft Design I",
          "Control Systems (Aerospace)",
          "CFD",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "Spacecraft Design II",
          "Avionics Systems",
          "UAV Technology",
          "Rocket Propulsion",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (Satellite Communication)",
          "Elective II (Space Mission Design)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III",
          "Aerospace Law",
          "Professional Ethics",
        ],
      },
    ],
    specializations: [
      {
        name: "Aerodynamics",
        desc: "Subsonic/supersonic flow, CFD simulation, wind tunnel testing, and aerodynamic design.",
      },
      {
        name: "Propulsion & Space",
        desc: "Jet engines, rocket motors, spacecraft propulsion, and in-space propulsion.",
      },
      {
        name: "Avionics & Navigation",
        desc: "Flight control computers, navigation systems, radar, and satellite communication.",
      },
      {
        name: "UAV & Drones",
        desc: "Drone design, autonomous flight, surveillance, and commercial UAV applications.",
      },
    ],
    careers: [
      { role: "Aerospace Engineer", avg: "13 LPA" },
      { role: "UAV Designer", avg: "15 LPA" },
      { role: "Avionics Engineer", avg: "14 LPA" },
      { role: "Propulsion Scientist", avg: "16 LPA" },
      { role: "Structural Analyst", avg: "12 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main or JEE Advanced",
      "Apply online via Aurexon Admissions Portal",
      "Submit 10+2 marksheet (minimum 80% PCM)",
      "Attend counselling and document verification",
      "Pay fee and confirm seat",
    ],
  },
  {
    slug: "biotechnology-engineering",
    name: "Biotechnology Engineering",
    emoji: "🧬",
    tagline: "Genomics, Bioinformatics & Pharma Tech",
    overview:
      "Biotechnology Engineering at Aurexon bridges biology and engineering to solve humanity's greatest challenges. From genetic engineering and bioprocess scale-up to bioinformatics and pharmaceutical manufacturing, our program is comprehensive and industry-aligned. Our biotech incubator has spawned 12+ startups, and graduates join Dr. Reddy's, Cipla, Biocon, and the Serum Institute of India.",
    seats: 60,
    faculty: 22,
    established: 1995,
    fee: "₹1,75,000",
    avgPlacement: "9 LPA",
    topCompanies: [
      "Dr. Reddy's",
      "Cipla",
      "Biocon",
      "Serum Institute",
      "Novartis India",
    ],
    eligibility: "10+2 with PCB or PCM 75%+, JEE Main or NEET score",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Mathematics I",
          "Biochemistry I",
          "Cell Biology",
          "C Programming",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Engineering Mathematics II",
          "Biochemistry II",
          "Microbiology",
          "Biostatistics",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Molecular Biology",
          "Genetic Engineering I",
          "Bioprocess Engineering I",
          "Enzymology",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Genetic Engineering II",
          "Bioprocess Engineering II",
          "Immunology",
          "Bioreactor Design",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "Bioinformatics",
          "Genomics & Proteomics",
          "Pharmaceutical Technology I",
          "Environmental Biotech",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "Industrial Biotech",
          "Pharmaceutical Technology II",
          "Clinical Research",
          "Biosafety & Ethics",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (Stem Cell Tech)",
          "Elective II (Nanobiotech)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III",
          "Regulatory Affairs",
          "Entrepreneurship",
        ],
      },
    ],
    specializations: [
      {
        name: "Pharmaceutical Biotech",
        desc: "Drug discovery, biopharmaceutical manufacturing, drug delivery systems, and clinical trials.",
      },
      {
        name: "Genetic Engineering",
        desc: "CRISPR, gene therapy, transgenic organisms, and synthetic biology.",
      },
      {
        name: "Bioinformatics",
        desc: "Sequence analysis, structural bioinformatics, systems biology, and computational drug design.",
      },
      {
        name: "Industrial Biotech",
        desc: "Fermentation technology, enzyme engineering, biofuels, and waste bioconversion.",
      },
    ],
    careers: [
      { role: "Bioprocess Engineer", avg: "9 LPA" },
      { role: "R&D Scientist", avg: "11 LPA" },
      { role: "Bioinformatics Analyst", avg: "12 LPA" },
      { role: "Quality Assurance", avg: "8 LPA" },
      { role: "Regulatory Affairs", avg: "10 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main or NEET with valid score",
      "Apply online via Aurexon Admissions Portal",
      "Submit 10+2 marksheet (minimum 75% PCB or PCM)",
      "Attend counselling and document verification",
      "Pay fee and confirm seat",
    ],
  },
  {
    slug: "information-technology",
    name: "Information Technology",
    emoji: "🖥️",
    tagline: "Web, Networks & Enterprise Systems",
    overview:
      "The Information Technology department at Auxeron focuses on building professionals skilled in enterprise software, web technologies, database management, networking, and cybersecurity. With dedicated labs for networking simulation, web development, and cloud platforms, students gain practical skills used by top IT companies worldwide. Our graduates work at Infosys, Wipro, TCS, Accenture, Capgemini, and global product companies.",
    seats: 120,
    faculty: 35,
    established: 1998,
    fee: "₹1,60,000",
    avgPlacement: "11 LPA",
    topCompanies: ["TCS", "Infosys", "Wipro", "Accenture", "Capgemini"],
    eligibility: "10+2 with PCM 75%+, JEE Main score",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Maths I",
          "C Programming",
          "Digital Logic",
          "Communication Skills",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Data Structures",
          "Database Management",
          "Computer Networks I",
          "OOP with Java",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Operating Systems",
          "Web Technologies",
          "DBMS Lab",
          "Software Engineering",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Computer Networks II",
          "Cloud Computing",
          "Mobile App Dev",
          "UI/UX Design",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "Information Security",
          "Big Data",
          "DevOps",
          "Project Management",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "AI & Machine Learning",
          "Microservices",
          "Blockchain Basics",
          "Data Analytics",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (IoT)",
          "Elective II (Quantum Computing)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III",
          "Startup Lab",
          "Professional Ethics",
        ],
      },
    ],
    specializations: [
      {
        name: "Web & Mobile Development",
        desc: "Full-stack development, PWA, React Native, REST & GraphQL APIs.",
      },
      {
        name: "Network & Cloud Engineering",
        desc: "AWS, Azure, GCP, SDN, and enterprise network design.",
      },
      {
        name: "Cybersecurity",
        desc: "Ethical hacking, VAPT, security operations, and digital forensics.",
      },
      {
        name: "Data Engineering",
        desc: "ETL pipelines, data warehousing, BI tools, and analytics platforms.",
      },
    ],
    careers: [
      { role: "Full Stack Developer", avg: "12 LPA" },
      { role: "Network Engineer", avg: "10 LPA" },
      { role: "Cloud Architect", avg: "18 LPA" },
      { role: "Cybersecurity Analyst", avg: "14 LPA" },
      { role: "Data Engineer", avg: "15 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main",
      "Apply online via Auxeron Admissions Portal",
      "Submit 10+2 marksheet (min 75% PCM)",
      "Attend counselling & document verification",
      "Pay fee and confirm seat",
    ],
  },
  {
    slug: "ai-data-science",
    name: "Artificial Intelligence & Data Science",
    emoji: "🤖",
    tagline: "Deep Learning, NLP & Intelligent Systems",
    overview:
      "Auxeron's AI & Data Science department is at the cutting edge of the fourth industrial revolution. With dedicated labs for GPU-accelerated deep learning, NLP research, and autonomous systems, students work on real-world datasets and AI products from Day 1. Industry partnerships with Google, Microsoft, and NVIDIA ensure our curriculum stays ahead of the curve. Graduates are in high demand at AI-first startups, FAANG companies, and research institutions worldwide.",
    seats: 90,
    faculty: 28,
    established: 2018,
    fee: "₹1,80,000",
    avgPlacement: "18 LPA",
    topCompanies: ["Google", "Microsoft", "Amazon", "NVIDIA", "OpenAI India"],
    eligibility: "10+2 with PCM 85%+, JEE Main score 95 percentile+",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Maths I",
          "Python Programming",
          "Statistics & Probability",
          "Data Structures",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Engineering Maths II",
          "Linear Algebra",
          "Database Systems",
          "Data Visualization",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Machine Learning I",
          "Algorithms",
          "Data Wrangling",
          "Business Analytics",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Machine Learning II",
          "Deep Learning I",
          "Big Data Analytics",
          "Computer Vision I",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "Deep Learning II",
          "NLP I",
          "Reinforcement Learning",
          "MLOps",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "NLP II",
          "Computer Vision II",
          "AI Ethics & Governance",
          "Generative AI",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (LLMs)",
          "Elective II (Autonomous Systems)",
          "Industry Internship",
          "Research Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III (Quantum ML)",
          "Startup Lab",
          "AI Policy",
        ],
      },
    ],
    specializations: [
      {
        name: "Deep Learning & Neural Networks",
        desc: "Transformers, CNNs, GANs, and foundation models.",
      },
      {
        name: "Natural Language Processing",
        desc: "LLMs, chatbots, text mining, and translation systems.",
      },
      {
        name: "Computer Vision",
        desc: "Object detection, image segmentation, medical imaging, and autonomous driving.",
      },
      {
        name: "Data Science & Analytics",
        desc: "Statistical modeling, A/B testing, BI, and predictive analytics.",
      },
    ],
    careers: [
      { role: "Machine Learning Engineer", avg: "20 LPA" },
      { role: "Data Scientist", avg: "18 LPA" },
      { role: "AI Research Scientist", avg: "25 LPA" },
      { role: "NLP Engineer", avg: "22 LPA" },
      { role: "Computer Vision Engineer", avg: "19 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main (95 percentile+)",
      "Apply online via Auxeron Portal",
      "Submit 10+2 marksheet (min 85% PCM)",
      "Take Auxeron AI Aptitude Test",
      "Attend counselling & confirm seat",
    ],
  },
  {
    slug: "industrial-engineering",
    name: "Industrial & Production Engineering",
    emoji: "🏭",
    tagline: "Manufacturing, Lean & Supply Chain",
    overview:
      "Industrial & Production Engineering at Auxeron prepares engineers who optimize manufacturing systems, improve supply chains, and drive operational excellence. Our students master lean manufacturing, Six Sigma, ERP systems, and industry 4.0 technologies. With dedicated CNC machining labs, simulation suites, and ties with Toyota, Maruti Suzuki, and Bosch, graduates become the backbone of India's manufacturing sector and global operations management.",
    seats: 60,
    faculty: 20,
    established: 2005,
    fee: "₹1,45,000",
    avgPlacement: "10 LPA",
    topCompanies: [
      "Toyota",
      "Maruti Suzuki",
      "Bosch",
      "Honeywell",
      "Caterpillar India",
    ],
    eligibility: "10+2 with PCM 75%+, JEE Main score",
    curriculum: [
      {
        sem: "Semester 1",
        subjects: [
          "Engineering Maths I",
          "Engineering Drawing",
          "Manufacturing Processes I",
          "C Programming",
        ],
      },
      {
        sem: "Semester 2",
        subjects: [
          "Engineering Maths II",
          "Manufacturing Processes II",
          "Material Science",
          "Thermodynamics",
        ],
      },
      {
        sem: "Semester 3",
        subjects: [
          "Production Planning & Control",
          "Industrial Statistics",
          "Work Study & Ergonomics",
          "Engineering Mechanics",
        ],
      },
      {
        sem: "Semester 4",
        subjects: [
          "Operations Research",
          "CAD/CAM",
          "Quality Engineering",
          "Industrial Management",
        ],
      },
      {
        sem: "Semester 5",
        subjects: [
          "Lean Manufacturing",
          "Supply Chain Management",
          "ERP Systems",
          "Project Management",
        ],
      },
      {
        sem: "Semester 6",
        subjects: [
          "Six Sigma & TQM",
          "Automation & Robotics",
          "Industry 4.0",
          "Simulation Modeling",
        ],
      },
      {
        sem: "Semester 7",
        subjects: [
          "Elective I (Additive Manufacturing)",
          "Elective II (Logistics)",
          "Industry Internship",
          "Mini Project",
        ],
      },
      {
        sem: "Semester 8",
        subjects: [
          "Capstone Project",
          "Elective III (Smart Factory)",
          "Operations Strategy",
          "Entrepreneurship",
        ],
      },
    ],
    specializations: [
      {
        name: "Lean & Six Sigma",
        desc: "Waste elimination, DMAIC, value stream mapping, and kaizen workshops.",
      },
      {
        name: "Supply Chain & Logistics",
        desc: "Demand planning, inventory optimization, and global supply networks.",
      },
      {
        name: "Manufacturing Systems",
        desc: "CNC, automation, flexible manufacturing, and smart factory integration.",
      },
      {
        name: "Quality Engineering",
        desc: "SPC, reliability engineering, metrology, and ISO standards compliance.",
      },
    ],
    careers: [
      { role: "Production Engineer", avg: "10 LPA" },
      { role: "Supply Chain Manager", avg: "12 LPA" },
      { role: "Quality Engineer", avg: "9 LPA" },
      { role: "Operations Manager", avg: "14 LPA" },
      { role: "IE Consultant", avg: "15 LPA" },
    ],
    admissionSteps: [
      "Clear JEE Main",
      "Apply online via Auxeron Admissions Portal",
      "Submit 10+2 marksheet (min 75% PCM)",
      "Attend counselling & document verification",
      "Pay fee and confirm seat",
    ],
  },
];

export function DepartmentPage() {
  const { dept } = useParams({ from: "/department/$dept" });
  const navigate = useNavigate();
  const department = departments.find((d) => d.slug === dept) ?? departments[0];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero */}
        <div
          className="py-24 px-4 text-center text-white relative overflow-hidden"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.18 0.055 248) 0%, oklch(0.26 0.07 248) 100%)",
          }}
        >
          <div className="absolute inset-0 blueprint-bg opacity-20" />
          <div className="relative z-10 max-w-4xl mx-auto">
            <div className="text-7xl mb-4">{department.emoji}</div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold mb-3">
              {department.name}
            </h1>
            <p className="text-gold text-lg font-semibold mb-6">
              {department.tagline}
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <button
                type="button"
                onClick={() => navigate({ to: "/academics" })}
                data-ocid="dept.secondary_button"
                className="flex items-center gap-2 border border-white/40 text-white/80 hover:text-white hover:border-white px-4 py-2 rounded-md text-sm transition-all"
              >
                <ArrowLeft className="w-4 h-4" /> Back to Departments
              </button>
              <button
                type="button"
                onClick={() => navigate({ to: "/admissions" })}
                data-ocid="dept.primary_button"
                className="bg-gold hover:bg-gold-dark text-navy-dark font-bold px-6 py-2 rounded-md text-sm uppercase tracking-wide transition-all"
              >
                Apply Now
              </button>
            </div>
          </div>
        </div>

        {/* Info cards */}
        <div className="bg-secondary py-8 border-b border-border">
          <div className="max-w-6xl mx-auto px-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              {
                icon: <Users className="w-5 h-5" />,
                label: "Seats",
                value: `${department.seats}`,
              },
              {
                icon: <GraduationCap className="w-5 h-5" />,
                label: "Faculty",
                value: `${department.faculty}`,
              },
              {
                icon: <Calendar className="w-5 h-5" />,
                label: "Established",
                value: `${department.established}`,
              },
              {
                icon: <DollarSign className="w-5 h-5" />,
                label: "Annual Fee",
                value: department.fee,
              },
            ].map((item) => (
              <div
                key={item.label}
                className="bg-white rounded-xl p-4 flex items-center gap-3 shadow-sm"
              >
                <div className="text-navy">{item.icon}</div>
                <div>
                  <div className="text-xs text-muted-foreground font-semibold uppercase tracking-wide">
                    {item.label}
                  </div>
                  <div className="font-bold text-navy text-lg">
                    {item.value}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="max-w-6xl mx-auto px-4 py-12">
          <Tabs defaultValue="overview" data-ocid="dept.tab">
            <TabsList className="mb-8 flex flex-wrap gap-1 h-auto bg-secondary">
              {[
                "overview",
                "curriculum",
                "specializations",
                "careers",
                "admissions",
              ].map((tab) => (
                <TabsTrigger
                  key={tab}
                  value={tab}
                  className="capitalize font-semibold data-[state=active]:bg-navy data-[state=active]:text-white"
                >
                  {tab}
                </TabsTrigger>
              ))}
            </TabsList>

            {/* Overview */}
            <TabsContent value="overview">
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <h2 className="font-display text-2xl font-bold text-navy mb-4">
                    About the Department
                  </h2>
                  <p className="text-muted-foreground leading-relaxed text-base mb-6">
                    {department.overview}
                  </p>
                  <div className="bg-navy/5 rounded-xl p-6">
                    <h3 className="font-bold text-navy mb-3 flex items-center gap-2">
                      <Award className="w-5 h-5 text-gold" /> Placement
                      Highlights
                    </h3>
                    <div className="flex items-center gap-6 flex-wrap">
                      <div>
                        <div className="text-3xl font-bold text-gold">
                          {department.avgPlacement}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Average Package
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {department.topCompanies.map((c) => (
                          <Badge key={c} className="bg-navy text-white">
                            {c}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="bg-navy rounded-xl p-6 text-white">
                    <h3 className="font-bold text-gold mb-4">Quick Facts</h3>
                    <ul className="space-y-3 text-sm">
                      <li className="flex gap-2">
                        <Star className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                        <span>NAAC A+ Accredited Department</span>
                      </li>
                      <li className="flex gap-2">
                        <BookOpen className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                        <span>4-year B.Tech + 2-year M.Tech programs</span>
                      </li>
                      <li className="flex gap-2">
                        <Building className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                        <span>Dedicated state-of-the-art labs</span>
                      </li>
                      <li className="flex gap-2">
                        <Users className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                        <span>{department.faculty} expert faculty members</span>
                      </li>
                      <li className="flex gap-2">
                        <Briefcase className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                        <span>Industry tie-ups and internships</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Curriculum */}
            <TabsContent value="curriculum">
              <h2 className="font-display text-2xl font-bold text-navy mb-6">
                B.Tech Curriculum (Semester-wise)
              </h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {department.curriculum.map((sem) => (
                  <div
                    key={sem.sem}
                    className="bg-white border border-border rounded-xl p-5 shadow-sm"
                  >
                    <h3 className="font-bold text-navy mb-3 text-base">
                      {sem.sem}
                    </h3>
                    <ul className="space-y-1">
                      {sem.subjects.map((subject) => (
                        <li
                          key={subject}
                          className="text-sm text-muted-foreground flex gap-2"
                        >
                          <span className="text-gold mt-1">▸</span> {subject}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Specializations */}
            <TabsContent value="specializations">
              <h2 className="font-display text-2xl font-bold text-navy mb-6">
                Specialization Tracks
              </h2>
              <div className="grid sm:grid-cols-2 gap-6">
                {department.specializations.map((spec, i) => (
                  <div
                    key={spec.name}
                    className="bg-white border border-border rounded-xl p-6 shadow-sm"
                    data-ocid={`dept.item.${i + 1}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-gold/20 flex items-center justify-center text-navy font-bold text-sm flex-shrink-0">
                        {i + 1}
                      </div>
                      <div>
                        <h3 className="font-bold text-navy mb-2">
                          {spec.name}
                        </h3>
                        <p className="text-muted-foreground text-sm leading-relaxed">
                          {spec.desc}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Careers */}
            <TabsContent value="careers">
              <h2 className="font-display text-2xl font-bold text-navy mb-6">
                Career Opportunities
              </h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                {department.careers.map((career, i) => (
                  <div
                    key={career.role}
                    className="bg-white border border-border rounded-xl p-5 shadow-sm"
                    data-ocid={`dept.card.${i + 1}`}
                  >
                    <Briefcase className="w-6 h-6 text-gold mb-3" />
                    <h3 className="font-bold text-navy mb-1">{career.role}</h3>
                    <div className="text-gold font-bold text-lg">
                      {career.avg}
                    </div>
                    <div className="text-muted-foreground text-xs">
                      Average CTC
                    </div>
                  </div>
                ))}
              </div>
              <div className="bg-navy rounded-xl p-6 text-white">
                <h3 className="font-bold text-gold mb-3">
                  Top Recruiting Companies
                </h3>
                <div className="flex flex-wrap gap-2">
                  {department.topCompanies.map((c) => (
                    <Badge
                      key={c}
                      variant="outline"
                      className="border-white/30 text-white text-sm px-3 py-1"
                    >
                      {c}
                    </Badge>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Admissions */}
            <TabsContent value="admissions">
              <div className="grid lg:grid-cols-2 gap-8">
                <div>
                  <h2 className="font-display text-2xl font-bold text-navy mb-4">
                    Eligibility & Process
                  </h2>
                  <div className="bg-gold/10 border border-gold/30 rounded-xl p-5 mb-6">
                    <h3 className="font-bold text-navy mb-2">
                      Eligibility Criteria
                    </h3>
                    <p className="text-muted-foreground">
                      {department.eligibility}
                    </p>
                  </div>
                  <h3 className="font-bold text-navy mb-3">Admission Steps</h3>
                  <ol className="space-y-3">
                    {department.admissionSteps.map((step, i) => (
                      <li
                        key={step}
                        className="flex gap-3 text-sm text-muted-foreground"
                      >
                        <span className="w-6 h-6 rounded-full bg-navy text-white text-xs flex items-center justify-center flex-shrink-0 font-bold">
                          {i + 1}
                        </span>
                        {step}
                      </li>
                    ))}
                  </ol>
                </div>
                <div>
                  <div className="bg-navy rounded-xl p-6 text-white">
                    <h3 className="font-bold text-gold mb-4">
                      Programme Details
                    </h3>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-white/60">Programme</span>
                        <span>B.Tech (4 Years)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">Total Seats</span>
                        <span>{department.seats}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">Annual Fee</span>
                        <span className="text-gold">{department.fee}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">Avg Placement</span>
                        <span className="text-gold">
                          {department.avgPlacement}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/60">Faculty Count</span>
                        <span>{department.faculty}</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigate({ to: "/admissions" })}
                      data-ocid="dept.submit_button"
                      className="mt-6 w-full bg-gold hover:bg-gold-dark text-navy-dark font-bold py-3 rounded-md uppercase tracking-wide transition-all"
                    >
                      Apply Now
                    </button>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  );
}
