import { useNavigate } from "@tanstack/react-router";
import {
  ArrowRight,
  BookOpen,
  Calendar,
  FlaskConical,
  GraduationCap,
  Layers,
  MapPin,
  Users,
} from "lucide-react";
import { motion } from "motion/react";
import { useEffect } from "react";
import { Footer } from "../components/Footer";
import { Header } from "../components/Header";
import { HeroSection } from "../components/HeroSection";
import { StatsBar } from "../components/StatsBar";

const sections = [
  {
    icon: BookOpen,
    title: "Academics",
    desc: "8 departments offering B.Tech, M.Tech and Ph.D programs. 30+ specializations, world-class faculty and state-of-the-art labs.",
    color: "bg-blue-50",
    path: "/academics",
    badge: "30+ Programs",
  },
  {
    icon: GraduationCap,
    title: "Admissions",
    desc: "Transparent, merit-based admission process. Apply for 2026 batch now. Scholarships and fee waivers available.",
    color: "bg-amber-50",
    path: "/admissions",
    badge: "Apply Now",
  },
  {
    icon: FlaskConical,
    title: "Research",
    desc: "500+ publications, ₹50Cr+ funded projects, 45 patents filed. Join cutting-edge research across 5 specialized centers.",
    color: "bg-purple-50",
    path: "/research",
    badge: "45 Patents",
  },
  {
    icon: MapPin,
    title: "Campus Life",
    desc: "60+ clubs, Olympic-size sports complex, 4,000-seat hostel, innovation hub, cafeterias and a vibrant 200-acre campus.",
    color: "bg-green-50",
    path: "/campus",
    badge: "200 Acres",
  },
  {
    icon: Calendar,
    title: "Events",
    desc: "AuxeroTech Fest, Aurex-Con cultural fest, Annual Sports Meet, Hackathons and Distinguished Lecture Series — a year full of action.",
    color: "bg-indigo-50",
    path: "/events",
    badge: "50+ Events/Year",
  },
  {
    icon: Layers,
    title: "Placements",
    desc: "98% placement rate. Average package 12.5 LPA, highest 52 LPA. 320+ companies including Google, Amazon, ISRO.",
    color: "bg-rose-50",
    path: "/placements",
    badge: "98% Placed",
  },
  {
    icon: Users,
    title: "Faculty",
    desc: "850+ distinguished faculty with global expertise. 60% with international experience, 100+ PhDs from IITs and IISc.",
    color: "bg-teal-50",
    path: "/faculty",
    badge: "850+ Faculty",
  },
];

export function HomePage() {
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen font-body">
      <Header />
      <main>
        <HeroSection />
        <StatsBar />

        {/* Section Preview Cards */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="font-display text-4xl font-bold text-navy uppercase tracking-wide gold-underline">
                Explore Aurexon
              </h2>
              <p className="mt-8 text-muted-foreground text-lg max-w-2xl mx-auto">
                Everything you need to know about life at Aurexon University
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {sections.map((s, i) => (
                <motion.div
                  key={s.path}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.07 }}
                  className={`rounded-2xl p-8 ${s.color} hover-lift flex flex-col`}
                  data-ocid={`home.item.${i + 1}`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 bg-navy rounded-xl flex items-center justify-center">
                      <s.icon className="w-6 h-6 text-gold" />
                    </div>
                    <span className="text-xs font-bold bg-navy text-gold px-3 py-1 rounded-full">
                      {s.badge}
                    </span>
                  </div>
                  <h3 className="font-display text-2xl font-bold text-navy mb-3">
                    {s.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed flex-1 mb-6">
                    {s.desc}
                  </p>
                  <button
                    type="button"
                    onClick={() => navigate({ to: s.path })}
                    data-ocid={`home.button.${i + 1}`}
                    className="flex items-center gap-2 font-bold text-navy hover:text-gold transition-colors text-sm uppercase tracking-wide"
                  >
                    Learn More <ArrowRight className="w-4 h-4" />
                  </button>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Quick Apply CTA */}
        <section
          className="py-20"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.18 0.055 248) 0%, oklch(0.25 0.065 248) 100%)",
          }}
        >
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="font-display text-4xl sm:text-5xl font-bold text-white mb-6">
                Ready to Begin Your
                <span className="block text-gold">Engineering Journey?</span>
              </h2>
              <p className="text-white/80 text-lg mb-10 max-w-2xl mx-auto">
                Applications for 2026 batch are open. Join thousands of
                engineers who chose Aurexon.
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <button
                  type="button"
                  onClick={() => navigate({ to: "/admissions" })}
                  data-ocid="home.primary_button"
                  className="bg-gold hover:bg-gold-dark text-navy-dark font-bold py-4 px-10 rounded-md text-base uppercase tracking-wide transition-all hover:shadow-xl hover:-translate-y-0.5"
                >
                  Start Application
                </button>
                <button
                  type="button"
                  onClick={() => navigate({ to: "/about" })}
                  data-ocid="home.secondary_button"
                  className="border-2 border-white text-white hover:bg-white hover:text-navy-dark font-bold py-4 px-10 rounded-md text-base uppercase tracking-wide transition-all"
                >
                  Learn About Us
                </button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
