import { motion } from "motion/react";
import { useEffect } from "react";
import { Footer } from "../components/Footer";
import { Header } from "../components/Header";
import { ResearchSection } from "../components/ResearchSection";

export function ResearchPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen font-body">
      <Header />
      <main>
        <section
          className="pt-32 pb-16 relative overflow-hidden"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.18 0.055 248) 0%, oklch(0.25 0.065 248) 100%)",
          }}
        >
          <div className="absolute inset-0 blueprint-bg opacity-30" />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-gold text-sm font-bold uppercase tracking-widest mb-3">
                Innovation & Discovery
              </div>
              <h1 className="font-display text-5xl font-bold text-white mb-4">
                Research at Aurexon
              </h1>
              <p className="text-white/70 text-lg max-w-2xl">
                5 research centers, 500+ publications, and ₹50Cr+ in funded
                projects pushing the boundaries of engineering.
              </p>
            </motion.div>
          </div>
        </section>
        <ResearchSection />
      </main>
      <Footer />
    </div>
  );
}
