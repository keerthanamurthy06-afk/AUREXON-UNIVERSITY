import { useNavigate } from "@tanstack/react-router";
import { motion } from "motion/react";
import { useEffect } from "react";
import { AcademicsSection } from "../components/AcademicsSection";
import { Footer } from "../components/Footer";
import { Header } from "../components/Header";

export function AcademicsPage() {
  const navigate = useNavigate();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen font-body">
      <Header />
      <main>
        {/* Page Banner */}
        <section
          className="pt-32 pb-16 relative overflow-hidden"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.18 0.055 248) 0%, oklch(0.25 0.065 248) 100%)",
          }}
        >
          <div className="absolute inset-0 blueprint-bg opacity-30" />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-gold text-sm font-bold uppercase tracking-widest mb-3">
                Aurexon University
              </div>
              <h1 className="font-display text-5xl font-bold text-white mb-4">
                Academic Programs
              </h1>
              <p className="text-white/70 text-lg max-w-2xl">
                Explore our 8 engineering departments offering undergraduate,
                postgraduate and doctoral programs.
              </p>
              <div className="flex gap-4 mt-8">
                <button
                  type="button"
                  onClick={() => navigate({ to: "/admissions" })}
                  data-ocid="academics.primary_button"
                  className="bg-gold hover:bg-gold-dark text-navy-dark font-bold py-3 px-8 rounded-md text-sm uppercase tracking-wide transition-all"
                >
                  Apply Now
                </button>
                <button
                  type="button"
                  onClick={() => navigate({ to: "/research" })}
                  data-ocid="academics.secondary_button"
                  className="border-2 border-white text-white hover:bg-white hover:text-navy-dark font-bold py-3 px-8 rounded-md text-sm uppercase tracking-wide transition-all"
                >
                  Research Centers
                </button>
              </div>
            </motion.div>
          </div>
        </section>

        <AcademicsSection />
      </main>
      <Footer />
    </div>
  );
}
