import { useQuery } from "@tanstack/react-query";
import type {
  Department,
  Event,
  Faculty,
  News,
  Placement,
  Program,
  ResearchCenter,
  Statistics,
} from "../backend.d";
import { useActor } from "./useActor";

export function useStatistics() {
  const { actor, isFetching } = useActor();
  return useQuery<Statistics | null>({
    queryKey: ["statistics"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getStatistics();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useDepartments() {
  const { actor, isFetching } = useActor();
  return useQuery<Department[]>({
    queryKey: ["departments"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getDepartments();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useFaculties() {
  const { actor, isFetching } = useActor();
  return useQuery<Faculty[]>({
    queryKey: ["faculties"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getFaculties();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useResearchCenters() {
  const { actor, isFetching } = useActor();
  return useQuery<ResearchCenter[]>({
    queryKey: ["researchCenters"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getResearchCenters();
    },
    enabled: !!actor && !isFetching,
  });
}

export function usePlacements() {
  const { actor, isFetching } = useActor();
  return useQuery<Placement[]>({
    queryKey: ["placements"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getPlacements();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useEvents() {
  const { actor, isFetching } = useActor();
  return useQuery<Event[]>({
    queryKey: ["events"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getEvents();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useNews() {
  const { actor, isFetching } = useActor();
  return useQuery<News[]>({
    queryKey: ["news"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getNewsAll();
    },
    enabled: !!actor && !isFetching,
  });
}

export function usePrograms() {
  const { actor, isFetching } = useActor();
  return useQuery<Program[]>({
    queryKey: ["programs"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getPrograms();
    },
    enabled: !!actor && !isFetching,
  });
}
