import { Toaster } from "@/components/ui/sonner";
import {
  Outlet,
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import { ChatWidget } from "./components/ChatWidget";
import { AboutPage } from "./pages/AboutPage";
import { AcademicsPage } from "./pages/AcademicsPage";
import { AdmissionsPage } from "./pages/AdmissionsPage";
import { CampusPage } from "./pages/CampusPage";
import { ContactPage } from "./pages/ContactPage";
import { DepartmentPage } from "./pages/DepartmentPage";
import { EventsPage } from "./pages/EventsPage";
import { FacultyPage } from "./pages/FacultyPage";
import { HomePage } from "./pages/HomePage";
import { PlacementsPage } from "./pages/PlacementsPage";
import { ResearchPage } from "./pages/ResearchPage";

const rootRoute = createRootRoute({
  component: () => (
    <>
      <Outlet />
      <Toaster richColors position="top-center" />
      <ChatWidget />
    </>
  ),
});

const homeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: HomePage,
});
const academicsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/academics",
  component: AcademicsPage,
});
const departmentRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/department/$dept",
  component: DepartmentPage,
});
const admissionsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/admissions",
  component: AdmissionsPage,
});
const researchRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/research",
  component: ResearchPage,
});
const campusRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/campus",
  component: CampusPage,
});
const eventsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/events",
  component: EventsPage,
});
const facultyRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/faculty",
  component: FacultyPage,
});
const placementsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/placements",
  component: PlacementsPage,
});
const aboutRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/about",
  component: AboutPage,
});
const contactRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/contact",
  component: ContactPage,
});

const routeTree = rootRoute.addChildren([
  homeRoute,
  academicsRoute,
  departmentRoute,
  admissionsRoute,
  researchRoute,
  campusRoute,
  eventsRoute,
  facultyRoute,
  placementsRoute,
  aboutRoute,
  contactRoute,
]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
