import Array "mo:core/Array";
import Time "mo:core/Time";
import Text "mo:core/Text";
import List "mo:core/List";
import Order "mo:core/Order";
import Map "mo:core/Map";
import Runtime "mo:core/Runtime";
import Iter "mo:core/Iter";
import Nat "mo:core/Nat";
import Int "mo:core/Int";

actor {
  type Department = {
    id : Nat;
    name : Text;
    description : Text;
    programs : [Text];
    facultyCount : Nat;
    establishedYear : Nat;
  };

  module Department {
    public func compare(dept1 : Department, dept2 : Department) : Order.Order {
      Nat.compare(dept1.id, dept2.id);
    };

    public func compareByName(dept1 : Department, dept2 : Department) : Order.Order {
      Text.compare(dept1.name, dept2.name);
    };
  };

  type Program = {
    id : Nat;
    name : Text;
    department : Text;
    duration : Nat;
    seats : Nat;
    eligibility : Text;
  };

  module Program {
    public func compare(prog1 : Program, prog2 : Program) : Order.Order {
      Nat.compare(prog1.id, prog2.id);
    };

    public func compareByName(prog1 : Program, prog2 : Program) : Order.Order {
      Text.compare(prog1.name, prog2.name);
    };
  };

  type Faculty = {
    id : Nat;
    name : Text;
    designation : Text;
    department : Text;
    specialization : Text;
    email : Text;
    publications : Nat;
  };

  module Faculty {
    public func compare(fac1 : Faculty, fac2 : Faculty) : Order.Order {
      Nat.compare(fac1.id, fac2.id);
    };

    public func compareByName(fac1 : Faculty, fac2 : Faculty) : Order.Order {
      Text.compare(fac1.name, fac2.name);
    };
  };

  type News = {
    id : Nat;
    title : Text;
    date : Int;
    category : Text;
    excerpt : Text;
    content : Text;
  };

  module News {
    public func compare(news1 : News, news2 : News) : Order.Order {
      Nat.compare(news1.id, news2.id);
    };

    public func compareByDate(news1 : News, news2 : News) : Order.Order {
      Int.compare(news2.date, news1.date); // Most recent first
    };
  };

  type Event = {
    id : Nat;
    title : Text;
    date : Int;
    location : Text;
    description : Text;
    category : Text;
  };

  module Event {
    public func compare(event1 : Event, event2 : Event) : Order.Order {
      Nat.compare(event1.id, event2.id);
    };

    public func compareByDate(event1 : Event, event2 : Event) : Order.Order {
      Int.compare(event1.date, event2.date);
    };
  };

  type ResearchCenter = {
    id : Nat;
    name : Text;
    description : Text;
    focusAreas : [Text];
    facultyMembers : [Text];
  };

  module ResearchCenter {
    public func compare(rc1 : ResearchCenter, rc2 : ResearchCenter) : Order.Order {
      Nat.compare(rc1.id, rc2.id);
    };

    public func compareByName(rc1 : ResearchCenter, rc2 : ResearchCenter) : Order.Order {
      Text.compare(rc1.name, rc2.name);
    };
  };

  type Placement = {
    id : Nat;
    company : Text;
    package : Float;
    year : Nat;
    studentsPlaced : Nat;
  };

  module Placement {
    public func compare(p1 : Placement, p2 : Placement) : Order.Order {
      Nat.compare(p1.id, p2.id);
    };

    public func compareByYear(p1 : Placement, p2 : Placement) : Order.Order {
      Nat.compare(p2.year, p1.year);
    };
  };

  type Statistics = {
    totalStudents : Nat;
    facultyCount : Nat;
    yearsEstablished : Nat;
    placementPercentage : Float;
  };

  let departments = Map.empty<Nat, Department>();
  let programs = Map.empty<Nat, Program>();
  let faculties = Map.empty<Nat, Faculty>();
  let newsArticles = Map.empty<Nat, News>();
  let events = Map.empty<Nat, Event>();
  let researchCenters = Map.empty<Nat, ResearchCenter>();
  let placements = Map.empty<Nat, Placement>();
  let statistics = List.empty<Statistics>();

  // Pre-seeded data
  departments.add(
    1,
    {
      id = 1;
      name = "Computer Science & Engineering";
      description = "Focuses on core computer science concepts and advanced technologies.";
      programs = ["B.Tech", "M.Tech", "PhD"];
      facultyCount = 30;
      establishedYear = 2005;
    },
  );

  departments.add(
    2,
    {
      id = 2;
      name = "Electrical Engineering";
      description = "Covers electrical systems, power engineering, and electronics.";
      programs = ["B.Tech", "M.Tech"];
      facultyCount = 20;
      establishedYear = 2010;
    },
  );

  programs.add(
    1,
    {
      id = 1;
      name = "B.Tech (Computer Science)";
      department = "Computer Science & Engineering";
      duration = 4;
      seats = 120;
      eligibility = "10+2 with 60% in PCM";
    },
  );

  programs.add(
    2,
    {
      id = 2;
      name = "M.Tech (VLSI Design)";
      department = "Electrical Engineering";
      duration = 2;
      seats = 30;
      eligibility = "Relevant B.Tech degree";
    },
  );

  faculties.add(
    1,
    {
      id = 1;
      name = "Dr. Anjali Mehta";
      designation = "Professor";
      department = "Computer Science & Engineering";
      specialization = "Machine Learning";
      email = "anjali.mehta@aurexon.edu";
      publications = 25;
    },
  );

  faculties.add(
    2,
    {
      id = 2;
      name = "Dr. Ravi Kumar";
      designation = "Associate Professor";
      department = "Electrical Engineering";
      specialization = "Embedded Systems";
      email = "ravi.kumar@aurexon.edu";
      publications = 18;
    },
  );

  newsArticles.add(
    1,
    {
      id = 1;
      title = "Aurexon Ranked #1 Emerging University";
      date = 1_645_184_000_000_000_000;
      category = "Rankings";
      excerpt = "Aurexon University tops the rankings for emerging institutions.";
      content = "Aurexon University has emerged as the #1 choice for students nationwide...";
    },
  );

  newsArticles.add(
    2,
    {
      id = 2;
      title = "New Robotics Lab Inaugurated";
      date = 1_651_552_000_000_000_000;
      category = "Innovation";
      excerpt = "State-of-the-art robotics lab launched for research and collaboration.";
      content = "The Robotics Lab aims to foster cutting-edge research in automation...";
    },
  );

  events.add(
    1,
    {
      id = 1;
      title = "Annual Tech Fest - Innovaton";
      date = 1_654_736_000_000_000_000;
      location = "Main Auditorium";
      description = "National-level technical festival with workshops, hackathons, and exhibitions.";
      category = "Fest";
    },
  );

  events.add(
    2,
    {
      id = 2;
      title = "International Conference on AI";
      date = 1_658_184_000_000_000_000;
      location = "Conference Hall";
      description = "3-day conference with keynote speakers, research presentations, and panel discussions.";
      category = "Conference";
    },
  );

  researchCenters.add(
    1,
    {
      id = 1;
      name = "Center for Artificial Intelligence";
      description = "Conducts advanced research in AI, ML, and Data Science.";
      focusAreas = ["Deep Learning", "NLP", "Computer Vision"];
      facultyMembers = ["Dr. Anjali Mehta", "Dr. Pooja Singh"];
    },
  );

  researchCenters.add(
    2,
    {
      id = 2;
      name = "Renewable Energy Research Center";
      description = "Works on sustainable energy solutions and technology innovation.";
      focusAreas = ["Solar Energy", "Smart Grids"];
      facultyMembers = ["Dr. Ravi Kumar", "Dr. Arun Sharma"];
    },
  );

  placements.add(
    1,
    {
      id = 1;
      company = "Tech Mahindra";
      package = 8.5;
      year = 2023;
      studentsPlaced = 30;
    },
  );

  placements.add(
    2,
    {
      id = 2;
      company = "Tata Consultancy Services";
      package = 7.2;
      year = 2023;
      studentsPlaced = 40;
    },
  );

  statistics.add(
    {
      totalStudents = 2400;
      facultyCount = 120;
      yearsEstablished = 18;
      placementPercentage = 92.5;
    },
  );

  public query ({ caller }) func getDepartment(id : Nat) : async Department {
    switch (departments.get(id)) {
      case (null) { Runtime.trap("Department not found") };
      case (?department) { department };
    };
  };

  public query ({ caller }) func getDepartments() : async [Department] {
    departments.values().toArray().sort(Department.compareByName);
  };

  public query ({ caller }) func getProgram(id : Nat) : async Program {
    switch (programs.get(id)) {
      case (null) { Runtime.trap("Program not found") };
      case (?program) { program };
    };
  };

  public query ({ caller }) func getPrograms() : async [Program] {
    programs.values().toArray().sort();
  };

  public query ({ caller }) func getFaculty(id : Nat) : async Faculty {
    switch (faculties.get(id)) {
      case (null) { Runtime.trap("Faculty not found") };
      case (?faculty) { faculty };
    };
  };

  public query ({ caller }) func getFaculties() : async [Faculty] {
    faculties.values().toArray().sort(Faculty.compareByName);
  };

  public query ({ caller }) func getNews(id : Nat) : async News {
    switch (newsArticles.get(id)) {
      case (null) { Runtime.trap("News not found") };
      case (?article) { article };
    };
  };

  public query ({ caller }) func getNewsAll() : async [News] {
    newsArticles.values().toArray().sort(News.compareByDate);
  };

  public query ({ caller }) func getEvents() : async [Event] {
    events.values().toArray().sort(Event.compareByDate);
  };

  public query ({ caller }) func getResearchCenters() : async [ResearchCenter] {
    researchCenters.values().toArray().sort(ResearchCenter.compareByName);
  };

  public query ({ caller }) func getPlacements() : async [Placement] {
    placements.values().toArray().sort(Placement.compareByYear);
  };

  public query ({ caller }) func getStatistics() : async Statistics {
    switch (statistics.first()) {
      case (?stats) { stats };
      case (null) { Runtime.trap("Statistics not found") };
    };
  };
};
